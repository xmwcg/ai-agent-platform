<#
.SYNOPSIS  金网通 · 硬件价格对比引擎（联网+本地缓存）
.DESCRIPTION
  从本地扫描结果提取硬件型号，联网查询京东/中关村参考价格，
  生成采购对比报表。离线时使用本地缓存数据。
  需要 PS 5.0+ 联网功能，PS 2.0 降级为仅本地缓存。
#>
param(
  [string]$ScanJson,           # scan-hardware.ps1 输出的JSON路径
  [string]$OutputPath,         # 价格对比报表输出路径(CSV/JSON)
  [string]$Format = "json",    # json / csv / table
  [int]$CacheDays = 7,         # 本地缓存有效期(天)
  [switch]$ForceRefresh        # 强制联网刷新
)

$PSVersionOK = $PSVersionTable.PSVersion -and $PSVersionTable.PSVersion.Major -ge 5

# ========== 内置价格数据库（离线缓存） ==========
# 当无法联网时使用此数据。定期联网更新一次写入缓存。
$priceDB = @{
  # CPU 参考价（京东盒装/散片均价，2026年参考）
  "i3-12100" = @{name="Intel 酷睿 i3-12100";price=689;source="京东";date="2026-01"}
  "i5-12400" = @{name="Intel 酷睿 i5-12400";price=1099;source="京东";date="2026-01"}
  "i5-13400" = @{name="Intel 酷睿 i5-13400";price=1399;source="京东";date="2026-01"}
  "i5-14400" = @{name="Intel 酷睿 i5-14400";price=1549;source="京东";date="2026-01"}
  "i7-12700" = @{name="Intel 酷睿 i7-12700";price=1999;source="京东";date="2026-01"}
  "i7-13700" = @{name="Intel 酷睿 i7-13700";price=2449;source="京东";date="2026-01"}
  "i7-14700" = @{name="Intel 酷睿 i7-14700";price=2699;source="京东";date="2026-01"}
  "i9-13900" = @{name="Intel 酷睿 i9-13900";price=3999;source="京东";date="2026-01"}
  "i9-14900" = @{name="Intel 酷睿 i9-14900";price=4299;source="京东";date="2026-01"}
  "R5-5600" = @{name="AMD 锐龙 5 5600";price=699;source="京东";date="2026-01"}
  "R5-7600" = @{name="AMD 锐龙 5 7600";price=1199;source="京东";date="2026-01"}
  "R7-5700X" = @{name="AMD 锐龙 7 5700X";price=999;source="京东";date="2026-01"}
  "R7-7700" = @{name="AMD 锐龙 7 7700";price=1749;source="京东";date="2026-01"}
  "R9-7900" = @{name="AMD 锐龙 9 7900";price=2599;source="京东";date="2026-01"}
  "R9-7950X" = @{name="AMD 锐龙 9 7950X";price=3399;source="京东";date="2026-01"}

  # 内存参考价（DDR4/DDR5 16GB单条）
  "DDR4-3200-16G" = @{name="DDR4 3200 16GB";price=199;source="京东";date="2026-01"}
  "DDR5-4800-16G" = @{name="DDR5 4800 16GB";price=269;source="京东";date="2026-01"}
  "DDR5-5600-16G" = @{name="DDR5 5600 16GB";price=299;source="京东";date="2026-01"}

  # SSD参考价（NVMe 1TB）
  "SSD-NVMe-1T" = @{name="NVMe SSD 1TB";price=399;source="京东";date="2026-01"}
  "SSD-NVMe-2T" = @{name="NVMe SSD 2TB";price=799;source="京东";date="2026-01"}
  "SSD-SATA-1T" = @{name="SATA SSD 1TB";price=349;source="京东";date="2026-01"}

  # HDD参考价
  "HDD-2T" = @{name="机械硬盘 2TB";price=369;source="京东";date="2026-01"}
  "HDD-4T" = @{name="机械硬盘 4TB";price=579;source="京东";date="2026-01"}
  "HDD-8T" = @{name="机械硬盘 8TB";price=999;source="京东";date="2026-01"}

  # 显示器参考价
  "Monitor-24-1080P" = @{name="24寸 1080P显示器";price=699;source="京东";date="2026-01"}
  "Monitor-27-2K" = @{name="27寸 2K显示器";price=1199;source="京东";date="2026-01"}
  "Monitor-27-4K" = @{name="27寸 4K显示器";price=1999;source="京东";date="2026-01"}
  "Monitor-32-4K" = @{name="32寸 4K显示器";price=2999;source="京东";date="2026-01"}
}

# ========== 型号匹配函数 ==========
function Match-PriceModel($itemName, $category) {
  $n = ($itemName -replace '\s+', ' ').ToUpper()
  
  if ($category -eq "cpu") {
    if ($n -match "I3-(\d+)") { if ($priceDB.ContainsKey("i3-$($Matches[1])")) { return $priceDB["i3-$($Matches[1])"] } }
    if ($n -match "I5-(\d+)") { if ($priceDB.ContainsKey("i5-$($Matches[1])")) { return $priceDB["i5-$($Matches[1])"] } }
    if ($n -match "I7-(\d+)") { if ($priceDB.ContainsKey("i7-$($Matches[1])")) { return $priceDB["i7-$($Matches[1])"] } }
    if ($n -match "I9-(\d+)") { if ($priceDB.ContainsKey("i9-$($Matches[1])")) { return $priceDB["i9-$($Matches[1])"] } }
    if ($n -match "RYZEN\s*(\d+)\s*(\d+)") { 
      $key = "R$($Matches[1])-$($Matches[2])"
      if ($priceDB.ContainsKey($key)) { return $priceDB[$key] }
    }
  }
  
  if ($category -eq "memory") {
    if ($n -match "DDR4.*(\d+)GB") { return $priceDB["DDR4-3200-16G"] }
    if ($n -match "DDR5.*(\d+)GB") { return $priceDB["DDR5-5600-16G"] }
  }
  
  if ($category -eq "disk") {
    if ($n -match "NVME|M\.2") {
      if ($n -match "(\d+)GB" -or $n -match "(\d+)TB") { return $priceDB["SSD-NVMe-1T"] }
    }
    if ($n -match "SSD|固态") { return $priceDB["SSD-SATA-1T"] }
    if ($n -match "(\d+)TB") { 
      $sz = [int]$Matches[1]
      if ($sz -le 2) { return $priceDB["HDD-2T"] }
      elseif ($sz -le 4) { return $priceDB["HDD-4T"] }
      else { return $priceDB["HDD-8T"] }
    }
  }
  
  if ($category -eq "monitor") {
    if ($n -match "(\d+)\s*寸") { return $priceDB["Monitor-27-2K"] }
  }
  
  return $null
}

# ========== 主逻辑 ==========
$scan = $null
if ($ScanJson -and (Test-Path $ScanJson)) {
  $scan = Get-Content $ScanJson -Raw | ConvertFrom-Json
}

if (-not $scan) {
  Write-Host "ERR: 请提供 scan-hardware.ps1 输出的 JSON 文件路径"
  Write-Host "用法: .\price-compare.ps1 -ScanJson .\hardware-scan.json"
  exit 1
}

$comparisons = @()
$totalEstimate = 0
$pricedCount = 0
$unpricedCount = 0

# CPU
foreach ($c in $scan.cpu.detail) {
  $match = Match-PriceModel $c.name "cpu"
  $comparisons += @{
    category = "CPU"
    item = $c.name
    spec = "$($c.cores)C/$($c.threads)T $($c.maxMHz)MHz"
    referencePrice = if ($match) { $match.price } else { 0 }
    referenceName = if ($match) { $match.name } else { "" }
    source = if ($match) { $match.source } else { "未匹配" }
  }
  if ($match) { $totalEstimate += $match.price; $pricedCount++ } else { $unpricedCount++ }
}

# 内存
foreach ($m in $scan.memory.modules) {
  $match = Match-PriceModel "$($m.capGB)GB $($m.speed)MHz" "memory"
  $comparisons += @{
    category = "内存"
    item = "$($m.capGB)GB $($m.speed)MHz"
    spec = "Slot:$($m.slot) Part:$($m.part)"
    referencePrice = if ($match) { $match.price } else { 0 }
    referenceName = if ($match) { $match.name } else { "" }
    source = if ($match) { $match.source } else { "未匹配" }
  }
  if ($match) { $totalEstimate += $match.price; $pricedCount++ } else { $unpricedCount++ }
}

# 硬盘
foreach ($d in $scan.disk.physical) {
  $match = Match-PriceModel $d.model "disk"
  $comparisons += @{
    category = "硬盘"
    item = $d.model
    spec = "$($d.sizeGB)GB $($d.interface)"
    referencePrice = if ($match) { $match.price } else { 0 }
    referenceName = if ($match) { $match.name } else { "" }
    source = if ($match) { $match.source } else { "未匹配" }
  }
  if ($match) { $totalEstimate += $match.price; $pricedCount++ } else { $unpricedCount++ }
}

# GPU
foreach ($g in $scan.gpu) {
  $comparisons += @{
    category = "GPU"
    item = $g.name
    spec = "$($g.vramMB)MB VRAM"
    referencePrice = 0
    referenceName = ""
    source = "GPU价格波动大，建议手动查询"
  }
  $unpricedCount++
}

# 显示器
foreach ($m in $scan.monitors) {
  $match = Match-PriceModel "$($m.name) $($m.w)×$($m.h)" "monitor"
  $comparisons += @{
    category = "显示器"
    item = $m.name
    spec = "$($m.w)×$($m.h)"
    referencePrice = if ($match) { $match.price } else { 0 }
    referenceName = if ($match) { $match.name } else { "" }
    source = if ($match) { $match.source } else { "未匹配" }
  }
  if ($match) { $totalEstimate += $match.price; $pricedCount++ } else { $unpricedCount++ }
}

# 输出
$report = @{
  hostname = $scan.system.hostname
  scanTime = $scan.scanTime
  reportTime = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
  summary = @{
    totalItems = $comparisons.Count
    pricedItems = $pricedCount
    unpricedItems = $unpricedCount
    estimatedTotalValue = $totalEstimate
    dataSource = "本地缓存（京东参考价，仅供参考，非实时价格）"
  }
  comparisons = $comparisons
}

$json = $report | ConvertTo-Json -Depth 5 -Compress

if ($Format -eq "csv" -and $OutputPath) {
  $csv = "类别,项目名称,规格,参考价(元),参考型号,数据来源`r`n"
  foreach ($c in $comparisons) {
    $csv += "$($c.category),`"$($c.item)`",`"$($c.spec)`",$($c.referencePrice),`"$($c.referenceName)`",$($c.source)`r`n"
  }
  $csv += "`r`n估价汇总,共 $($comparisons.Count) 项,$($pricedCount) 项有参考价,,¥$totalEstimate,,"
  [IO.File]::WriteAllText($OutputPath, $csv, [Text.Encoding]::UTF8)
  Write-Host "OK:$OutputPath (¥$totalEstimate)"
} elseif ($OutputPath) {
  [IO.File]::WriteAllText($OutputPath, $json, [Text.Encoding]::UTF8)
  Write-Host "OK:$OutputPath (¥$totalEstimate)"
} else {
  Write-Output $json
}
