<#
.SYNOPSIS  金网通 · 全量资产扫描（一键采集硬件+软件+网络）
.DESCRIPTION
  串联 scan-hardware.ps1 + scan-software.ps1，输出整合JSON和CSV报表。
  所有采集结果写入 console-data\ 目录供资产管理模块入库。
#>
param(
  [string]$OutputDir = "$PSScriptRoot\console-data",
  [switch]$IncludeSoftware,     # 包含软件扫描（稍慢）
  [switch]$IncludePriceCompare, # 包含价格对比
  [switch]$ExportCsv,           # 同时导出CSV
  [switch]$Quiet                # 静默模式
)

$startTime = Get-Date

# 确保输出目录存在
if (-not (Test-Path $OutputDir)) { New-Item -ItemType Directory -Path $OutputDir -Force | Out-Null }

$hostname = $env:COMPUTERNAME
$timestamp = Get-Date -Format 'yyyyMMdd-HHmmss'

# ========== 1. 硬件扫描 ==========
if (-not $Quiet) { Write-Host "===== [1/4] 硬件扫描 =====" -ForegroundColor Cyan }
$hwFile = "$OutputDir\$($hostname)_hardware_$timestamp.json"
try {
  $hwJson = & "$PSScriptRoot\scan-hardware.ps1"
  [IO.File]::WriteAllText($hwFile, $hwJson, [Text.Encoding]::UTF8)
  if (-not $Quiet) { Write-Host "  OK: $hwFile" -ForegroundColor Green }
} catch {
  if (-not $Quiet) { Write-Host "  ERR: $_" -ForegroundColor Red }
  $hwFile = $null
}

# ========== 2. 软件扫描（可选） ==========
if ($IncludeSoftware) {
  if (-not $Quiet) { Write-Host "`n===== [2/4] 软件扫描 =====" -ForegroundColor Cyan }
  $swFile = "$OutputDir\$($hostname)_software_$timestamp.json"
  try {
    if (Test-Path "$PSScriptRoot\scan-software.ps1") {
      $swJson = & "$PSScriptRoot\scan-software.ps1"
      [IO.File]::WriteAllText($swFile, $swJson, [Text.Encoding]::UTF8)
      if (-not $Quiet) { Write-Host "  OK: $swFile" -ForegroundColor Green }
    } else {
      if (-not $Quiet) { Write-Host "  WARN: scan-software.ps1 未找到，跳过" -ForegroundColor Yellow }
      $swFile = $null
    }
  } catch {
    if (-not $Quiet) { Write-Host "  ERR: $_" -ForegroundColor Red }
    $swFile = $null
  }
} else {
  $swFile = $null
  if (-not $Quiet) { Write-Host "`n===== [2/4] 软件扫描（跳过，加 -IncludeSoftware 开启）=====" -ForegroundColor DarkGray }
}

# ========== 3. 价格对比（可选） ==========
if ($IncludePriceCompare -and $hwFile) {
  if (-not $Quiet) { Write-Host "`n===== [3/4] 价格对比 =====" -ForegroundColor Cyan }
  $pcFile = "$OutputDir\$($hostname)_price_$timestamp.json"
  try {
    if (Test-Path "$PSScriptRoot\price-compare.ps1") {
      $pcJson = & "$PSScriptRoot\price-compare.ps1" -ScanJson $hwFile
      [IO.File]::WriteAllText($pcFile, $pcJson, [Text.Encoding]::UTF8)
      if (-not $Quiet) { Write-Host "  OK: $pcFile" -ForegroundColor Green }
    } else {
      if (-not $Quiet) { Write-Host "  WARN: price-compare.ps1 未找到" -ForegroundColor Yellow }
      $pcFile = $null
    }
  } catch {
    if (-not $Quiet) { Write-Host "  ERR: $_" -ForegroundColor Red }
    $pcFile = $null
  }
} else {
  $pcFile = $null
  if (-not $Quiet) { Write-Host "`n===== [3/4] 价格对比（跳过，加 -IncludePriceCompare 开启）=====" -ForegroundColor DarkGray }
}


# ========== 4. USB/外设扫描 ==========
$usbFile = "$OutputDir\$($hostname)_usb_$timestamp.json"
try {
  if (Test-Path "$PSScriptRoot\usb-scanner.ps1") {
    $usbJson = & "$PSScriptRoot\usb-scanner.ps1"
    [IO.File]::WriteAllText($usbFile, $usbJson, [Text.Encoding]::UTF8)
    if (-not $Quiet) { Write-Host "  OK: $usbFile" -ForegroundColor Green }
  } else {
    if (-not $Quiet) { Write-Host "  WARN: usb-scanner.ps1 未找到" -ForegroundColor Yellow }
    $usbFile = $null
  }
} catch {
  if (-not $Quiet) { Write-Host "  ERR: $_" -ForegroundColor Red }
  $usbFile = $null
}

# ========== 汇总 ==========
$duration = [math]::Round(((Get-Date) - $startTime).TotalSeconds, 1)
if (-not $Quiet) {
  Write-Host "`n===== 扫描完成 ($($duration)秒) =====" -ForegroundColor Cyan
  Write-Host "  硬件: $(if($hwFile){$hwFile}else{'失败'})"
  Write-Host "  软件: $(if($swFile){$swFile}else{'跳过'})"
  Write-Host "  USB:  $(if($usbFile){$usbFile}else{'跳过'})"
  Write-Host "  价格: $(if($pcFile){$pcFile}else{'跳过'})"
  Write-Host ""
  Write-Host "→ 运行 .\asset-manager.ps1 -ImportJson <硬件JSON> 可导入资产库（含生命周期）" -ForegroundColor White
  Write-Host "→ 运行 .\health-check.ps1 -AutoFix 可一键环境修复" -ForegroundColor White
}

# 整合输出
$result = @{
  hostname = $hostname
  scanTime = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
  durationSeconds = $duration
  outputs = @{
    hardware = if ($hwFile) { $hwFile } else { $null }
    software = if ($swFile) { $swFile } else { $null }
    priceCompare = if ($pcFile) { $pcFile } else { $null }
  }
}

$result | ConvertTo-Json -Depth 4 -Compress

