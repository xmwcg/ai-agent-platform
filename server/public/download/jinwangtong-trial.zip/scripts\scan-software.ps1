<#
.SYNOPSIS  金网通 · 已安装软件扫描与许可证审计
.DESCRIPTION
  PS 2.0+ 全兼容。扫描已安装软件清单、识别许可证状态、检测EOL/过期软件。
  输出 JSON 到 stdout，供资产管理模块入库。
#>
param([string]$OutputPath, [switch]$IncludeUpdates, [switch]$LicenseAudit)

$PSVersionOK = $PSVersionTable.PSVersion -and $PSVersionTable.PSVersion.Major -ge 5

function Safe-WMI { param([string]$Class,$ns="root\cimv2")
  try { if($PSVersionOK){Get-CimInstance -ClassName $Class -Namespace $ns -ErrorAction Stop}else{Get-WmiObject -Class $Class -Namespace $ns -ErrorAction Stop} } catch{$null}
}

# ========== 1. 通过注册表获取已安装软件 ==========
$apps = @()
$regPaths = @(
  "HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*",
  "HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*",
  "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*"
)
foreach ($regPath in $regPaths) {
  try {
    $items = Get-ItemProperty $regPath -ErrorAction SilentlyContinue | Where-Object { $_.DisplayName -and $_.DisplayName -ne "" }
    foreach ($i in $items) {
      $apps += @{
        name = ($i.DisplayName -replace '\s+', ' ').Trim()
        version = if ($i.DisplayVersion) { $i.DisplayVersion.Trim() } else { "" }
        publisher = if ($i.Publisher) { $i.Publisher.Trim() } else { "" }
        installDate = if ($i.InstallDate) { $i.InstallDate.Trim() } else { "" }
        installLocation = if ($i.InstallLocation) { $i.InstallLocation.Trim() } else { "" }
        estimatedSizeKB = if ($i.EstimatedSize) { $i.EstimatedSize } else { 0 }
        source = "Registry"
      }
    }
  } catch {}
}

# 去重
$unique = @{}; $deduped = @()
foreach ($a in $apps) {
  $key = "$($a.name)|$($a.version)"
  if (-not $unique.ContainsKey($key)) { $unique[$key] = $true; $deduped += $a }
}
$apps = $deduped

# ========== 2. 安全审计 ==========
$secProducts = @("Microsoft Defender","火绒","360","腾讯电脑管家","金山毒霸","卡巴斯基","McAfee","Symantec","Norton","ESET","Bitdefender")
$foundSecurity = @()
foreach ($sp in $secProducts) {
  if (($apps | Where-Object { $_.name -like "*$sp*" })) { $foundSecurity += $sp }
}

# EOL检测
$eolPatterns = @{
  "Windows 7" = "2020年1月停止支持"
  "Windows 8.1" = "2023年1月停止支持"
  "Office 2010" = "2020年10月停止支持"
  "Office 2013" = "2023年4月停止支持"
  "Java 8" = "公共更新已停止"
}
$eolFound = @()
foreach ($app in $apps) {
  foreach ($pattern in $eolPatterns.Keys) {
    if ($app.name -like "*$pattern*") {
      $eolFound += @{ name = $app.name; version = $app.version; risk = $eolPatterns[$pattern] }
      break
    }
  }
}

# 远程工具
$remoteTools = @("TeamViewer","AnyDesk","向日葵","ToDesk","RustDesk","VNC","Radmin","Splashtop")
$foundRemote = @()
foreach ($rt in $remoteTools) {
  $match = $apps | Where-Object { $_.name -like "*$rt*" } | Select-Object -First 1
  if ($match) { $foundRemote += @{ name = $rt; version = $match.version } }
}

# 开发工具
$devTools = @("Visual Studio","VS Code","IntelliJ","PyCharm","Node.js","Python","Git","Docker","MySQL","PostgreSQL")
$foundDev = @()
foreach ($dt in $devTools) {
  $match = $apps | Where-Object { $_.name -like "*$dt*" } | Select-Object -First 1
  if ($match) { $foundDev += @{ name = $dt; version = $match.version } }
}

# ========== 3. 分类统计 ==========
$categoryStats = @{}
foreach ($a in $apps) {
  $cat = "Other"
  $n = $a.name.ToLower()
  if ($n -match "microsoft|office|excel|word|edge|onedrive|teams") { $cat = "Microsoft" }
  elseif ($n -match "adobe|photoshop|acrobat|premiere") { $cat = "Adobe" }
  elseif ($n -match "chrome|google") { $cat = "Google" }
  elseif ($n -match "java|python|node|git|docker|visual|intellij|eclipse|vscode") { $cat = "DevTools" }
  elseif ($n -match "wps|libre") { $cat = "Office" }
  elseif ($n -match "360|火绒|卡巴|mcafee|symantec|norton|eset|bitdefender|defender") { $cat = "Security" }
  elseif ($n -match "teamviewer|anydesk|向日葵|todesk|vnc") { $cat = "RemoteAccess" }
  if (-not $categoryStats.ContainsKey($cat)) { $categoryStats[$cat] = 0 }
  $categoryStats[$cat]++
}

$out = @{
  scanTime = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
  hostname = $env:COMPUTERNAME
  software = @{
    totalCount = $apps.Count
    byCategory = $categoryStats
    applications = $apps | Select-Object -First 200
  }
  security = @{
    securityProducts = $foundSecurity
    eolSoftware = $eolFound
    remoteAccessTools = $foundRemote
  }
  developmentTools = $foundDev
}

$json = $out | ConvertTo-Json -Depth 6 -Compress
if ($OutputPath) {
  [IO.File]::WriteAllText($OutputPath, $json, [Text.Encoding]::UTF8)
  Write-Host "OK:$OutputPath"
} else {
  Write-Output $json
}
