<#
.SYNOPSIS  金网通 · 资产管理系统 V2.1 — 增强版（生命周期+CSV导入+批量管理）
.DESCRIPTION
  在 V2 基础上新增：
  - 资产生命周期（购入日期/维保到期/报废日期/状态）
  - CSV 模板导入（支持批量录入）
  - CSV 模板导出（含表头，供用户填写后导入）
  - 资产搜索与统计
#>
param(
  [string]$ImportJson,          # scan-hardware/scan-all 输出的 JSON
  [string]$ImportCsv,           # CSV 批量导入
  [string]$ExportFormat = "csv",# csv / json
  [string]$ExportPath,          # 导出路径
  [string]$ExportTemplate,      # 导出空CSV模板供手动填写
  [switch]$ListAssets,          # 列出所有资产
  [string]$Search,              # 搜索资产（按名称/类别/主机名）
  [string]$DbPath = "$PSScriptRoot\console-data\asset-db.json",
  [switch]$Stats,               # 资产统计
  [switch]$LifecycleCheck       # 维保到期检查
)

$dbDir = Split-Path $DbPath -Parent
if (-not (Test-Path $dbDir)) { New-Item -ItemType Directory -Path $dbDir -Force | Out-Null }

# ========== 数据库操作 ==========
function Get-Assets {
  if (Test-Path $DbPath) {
    try { $data = Get-Content $DbPath -Raw | ConvertFrom-Json; return @($data) }
    catch { return @() }
  }
  return @()
}

function Save-Assets($data) {
  [IO.File]::WriteAllText($DbPath, ($data | ConvertTo-Json -Depth 8), [Text.Encoding]::UTF8)
}

# ========== CSV 模板导出 ==========
if ($ExportTemplate) {
  $template = "hostname,category,itemName,manufacturer,model,spec,serialNumber,purchaseDate,warrantyExpire,retireDate,status,location,department,notes`r`n"
  $template += "PC01,cpu,Intel Core i5-12400,Intel,i5-12400,6C/12T 2.5GHz,SN123456,2024-01-15,2027-01-15,,active,3楼A区,技术部,开发用机`r`n"
  $template += "PC01,memory,DDR4 16GB,Kingston,KF432C16BB/16,3200MHz,SN789012,2024-01-15,2027-01-15,,active,3楼A区,技术部,`r`n"
  $template += "PC01,disk,NVMe SSD 512GB,Samsung,980 PRO,512GB PCIe4.0,SN345678,2024-01-15,2027-01-15,,active,3楼A区,技术部,系统盘`r`n"
  $template += "PC01,monitor,DELL U2723QE,DELL,U2723QE,27寸 4K,SN901234,2024-01-15,2027-01-15,,active,3楼A区,技术部,主显示器`r`n"
  
  [IO.File]::WriteAllText($ExportTemplate, $template, [Text.Encoding]::UTF8)
  Write-Host "OK: CSV模板已导出 -> $ExportTemplate"
  Write-Host "提示: 用Excel打开编辑后，运行 asset-manager.ps1 -ImportCsv $ExportTemplate 导入"
  exit 0
}

# ========== JSON 导入（增强版，含生命周期默认值） ==========
function Import-AssetFromJson($jsonPath) {
  $data = Get-Content $jsonPath -Raw | ConvertFrom-Json
  $assets = @(Get-Assets)
  $sys = $data.system
  $ts = $data.scanTime
  $hostname = $sys.hostname
  $today = (Get-Date -Format 'yyyy-MM-dd')
  $warranty3y = (Get-Date).AddYears(3).ToString('yyyy-MM-dd')

  # 辅助函数：生成资产记录
  function New-AssetItem($category, $itemName, $manufacturer, $model, $spec, $serial, $location, $dept, $notes) {
    return @{
      id = [guid]::NewGuid().ToString("N").Substring(0, 8)
      hostname = $hostname
      scanTime = $ts
      category = $category
      itemName = $itemName
      manufacturer = if ($manufacturer) { $manufacturer } else { $sys.manufacturer }
      model = $model
      spec = $spec
      serialNumber = if ($serial) { $serial } else { "" }
      purchaseDate = $today
      warrantyExpire = $warranty3y
      retireDate = ""
      status = "active"
      location = if ($location) { $location } else { "" }
      department = if ($dept) { $dept } else { "" }
      notes = if ($notes) { $notes } else { "" }
      createdAt = $today
    }
  }

  # 系统
  $assets += New-AssetItem "system" $sys.osCaption "" $sys.model "$($sys.osCaption) $($sys.osArch)" $sys.serial "" "" ""

  # CPU
  foreach ($c in $data.cpu.detail) {
    $assets += New-AssetItem "cpu" $c.name "" $c.name "$($c.cores)C/$($c.threads)T $($c.maxMHz)MHz" "" "" "" ""
  }

  # 内存
  foreach ($m in $data.memory.modules) {
    $assets += New-AssetItem "memory" "$($m.capGB)GB $($m.speed)MHz" "" $m.part "Slot:$($m.slot)" $m.serial "" "" ""
  }

  # 硬盘
  foreach ($d in $data.disk.physical) {
    $assets += New-AssetItem "disk" "$($d.sizeGB)GB $($d.interface)" "" $d.model $d.interface $d.serial "" "" ""
  }

  # GPU
  foreach ($g in $data.gpu) {
    if ($g.vramMB -gt 0) {
      $assets += New-AssetItem "gpu" $g.name "" $g.name "$($g.vramMB)MB VRAM" "" "" "" ""
    }
  }

  # 网卡
  foreach ($n in $data.network) {
    $assets += New-AssetItem "network" $n.name "" $n.name "MAC:$($n.mac)" "" "" "" ""
  }

  # 主板
  $mb = $data.motherboard
  $assets += New-AssetItem "motherboard" "主板" $mb.manufacturer $mb.product "" $mb.serial "" "" ""

  # 显示器
  foreach ($m in $data.monitors) {
    $assets += New-AssetItem "monitor" ($m.name -replace '\s+',' ') "" $m.name "$($m.w)x$($m.h)" "" "" "" ""
  }

  Save-Assets $assets
  Write-Host "OK: $($assets.Count) 条资产已入库 -> $DbPath"
}

# ========== CSV 批量导入 ==========
if ($ImportCsv -and (Test-Path $ImportCsv)) {
  $assets = @(Get-Assets)
  $lines = Get-Content $ImportCsv -Encoding UTF8
  $headerLine = $lines[0]
  $headers = $headerLine -split ','

  $imported = 0
  for ($i = 1; $i -lt $lines.Count; $i++) {
    $line = $lines[$i].Trim()
    if (-not $line) { continue }
    
    # 简单CSV解析（处理引号内逗号）
    $values = @()
    $inQuote = $false
    $current = ""
    foreach ($ch in $line.ToCharArray()) {
      if ($ch -eq '"') { $inQuote = -not $inQuote; continue }
      if ($ch -eq ',' -and -not $inQuote) { $values += $current.Trim('"'); $current = "" }
      else { $current += $ch }
    }
    $values += $current.Trim('"')
    
    if ($values.Count -lt 4) { continue }
    
    $asset = @{
      id = [guid]::NewGuid().ToString("N").Substring(0, 8)
      hostname = $values[0]
      category = $values[1]
      itemName = $values[2]
      manufacturer = if ($values.Count -gt 3) { $values[3] } else { "" }
      model = if ($values.Count -gt 4) { $values[4] } else { "" }
      spec = if ($values.Count -gt 5) { $values[5] } else { "" }
      serialNumber = if ($values.Count -gt 6) { $values[6] } else { "" }
      purchaseDate = if ($values.Count -gt 7) { $values[7] } else { "" }
      warrantyExpire = if ($values.Count -gt 8) { $values[8] } else { "" }
      retireDate = if ($values.Count -gt 9) { $values[9] } else { "" }
      status = if ($values.Count -gt 10) { $values[10] } else { "active" }
      location = if ($values.Count -gt 11) { $values[11] } else { "" }
      department = if ($values.Count -gt 12) { $values[12] } else { "" }
      notes = if ($values.Count -gt 13) { $values[13] } else { "" }
      createdAt = (Get-Date -Format 'yyyy-MM-dd')
      scanTime = ""
    }
    $assets += $asset
    $imported++
  }
  
  Save-Assets $assets
  Write-Host "OK: CSV 导入 $imported 条 -> $DbPath（共 $($assets.Count) 条）"
  exit 0
}

# ========== 维保到期检查 ==========
if ($LifecycleCheck) {
  $assets = @(Get-Assets)
  $today = Get-Date
  $warnDays = 90
  $warnDate = $today.AddDays($warnDays)
  
  Write-Host "===== 维保到期预警 ====="
  Write-Host "今天: $($today.ToString('yyyy-MM-dd')) | 预警期: $warnDays 天内`n"
  
  $warnings = @()
  foreach ($a in $assets) {
    if (-not $a.warrantyExpire -or $a.warrantyExpire -eq "") { continue }
    try {
      $expire = [DateTime]::Parse($a.warrantyExpire)
      $daysLeft = ($expire - $today).Days
      if ($daysLeft -le $warnDays) {
        $warnings += @{ asset=$a; daysLeft=$daysLeft }
        
        $color = if ($daysLeft -le 0) { "RED" } elseif ($daysLeft -le 30) { "YELLOW" } else { "GREEN" }
        Write-Host "[$color] $($a.hostname) | $($a.category) | $($a.itemName) | 到期: $($a.warrantyExpire) | 剩余: $daysLeft 天"
      }
    } catch {}
  }
  
  if ($warnings.Count -eq 0) {
    Write-Host "✅ 所有资产维保正常，无到期预警"
  } else {
    Write-Host "`n共 $($warnings.Count) 项需要关注"
  }
  exit 0
}

# ========== 资产统计 ==========
if ($Stats) {
  $assets = @(Get-Assets)
  Write-Host "===== 资产统计 ====="
  Write-Host "总资产数: $($assets.Count)`n"
  
  # 按类别统计
  $byCategory = @{}
  foreach ($a in $assets) {
    $cat = if ($a.category) { $a.category } else { "other" }
    if (-not $byCategory.ContainsKey($cat)) { $byCategory[$cat] = 0 }
    $byCategory[$cat]++
  }
  
  Write-Host "按类别:"
  foreach ($key in ($byCategory.Keys | Sort-Object)) {
    Write-Host "  $key : $($byCategory[$key]) 条"
  }
  
  # 按主机统计
  $byHost = @{}
  foreach ($a in $assets) {
    $h = if ($a.hostname) { $a.hostname } else { "unknown" }
    if (-not $byHost.ContainsKey($h)) { $byHost[$h] = 0 }
    $byHost[$h]++
  }
  
  Write-Host "`n按主机:"
  foreach ($key in ($byHost.Keys | Sort-Object)) {
    Write-Host "  $key : $($byHost[$key]) 条"
  }
  
  # 按状态统计
  $byStatus = @{}
  foreach ($a in $assets) {
    $s = if ($a.status) { $a.status } else { "active" }
    if (-not $byStatus.ContainsKey($s)) { $byStatus[$s] = 0 }
    $byStatus[$s]++
  }
  
  Write-Host "`n按状态:"
  foreach ($key in ($byStatus.Keys | Sort-Object)) {
    Write-Host "  $key : $($byStatus[$key]) 条"
  }
  
  exit 0
}

# ========== 主入口 ==========
if ($ImportJson) { Import-AssetFromJson $ImportJson }

if ($ListAssets -or $Search) {
  $assets = @(Get-Assets)
  
  if ($Search) {
    $assets = $assets | Where-Object {
      ($_.itemName -like "*$Search*") -or
      ($_.category -like "*$Search*") -or
      ($_.hostname -like "*$Search*") -or
      ($_.manufacturer -like "*$Search*") -or
      ($_.model -like "*$Search*") -or
      ($_.department -like "*$Search*") -or
      ($_.notes -like "*$Search*")
    }
    Write-Host "搜索 '$Search' 找到 $($assets.Count) 条"
  }
  
  if ($assets.Count -eq 0) { Write-Host "(空)"; exit 0 }
  
  Write-Host "ID`t主机名`t类别`t项目`t厂商`t型号`t规格`t购入`t维保到期`t状态`t位置`t部门"
  Write-Host ("-" * 120)
  foreach ($a in $assets) {
    Write-Host "$($a.id)`t$($a.hostname)`t$($a.category)`t$($a.itemName)`t$($a.manufacturer)`t$($a.model)`t$($a.spec)`t$($a.purchaseDate)`t$($a.warrantyExpire)`t$($a.status)`t$($a.location)`t$($a.department)"
  }
  Write-Host ""
  Write-Host "总计: $($assets.Count) 条资产"
}

if ($ExportPath) {
  $assets = @(Get-Assets)
  
  if ($ExportFormat -eq "csv") {
    $csv = "id,hostname,category,itemName,manufacturer,model,spec,serialNumber,purchaseDate,warrantyExpire,retireDate,status,location,department,notes,createdAt`r`n"
    foreach ($a in $assets) {
      $csv += "`"$($a.id)`",`"$($a.hostname)`",`"$($a.category)`",`"$($a.itemName)`",`"$($a.manufacturer)`",`"$($a.model)`",`"$($a.spec)`",`"$($a.serialNumber)`",`"$($a.purchaseDate)`",`"$($a.warrantyExpire)`",`"$($a.retireDate)`",`"$($a.status)`",`"$($a.location)`",`"$($a.department)`",`"$($a.notes)`",`"$($a.createdAt)`"`r`n"
    }
    [IO.File]::WriteAllText($ExportPath, $csv, [Text.Encoding]::UTF8)
    Write-Host "OK: $ExportPath ($($assets.Count) 条)"
  } else {
    $assets | ConvertTo-Json -Depth 8 | Out-File $ExportPath -Encoding UTF8
    Write-Host "OK: $ExportPath ($($assets.Count) 条)"
  }
}
