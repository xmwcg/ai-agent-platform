<#
.SYNOPSIS  金网通 · USB与外设扫描器
.DESCRIPTION
  PS 2.0+ 全兼容。扫描本机连接的 USB 设备、外设、输入设备。
  包括：USB存储/键鼠/摄像头/智能卡读卡器/蓝牙适配器等。
  输出 JSON 供资产管理模块入库。
#>
param([string]$OutputPath)

$PSVersionOK = $PSVersionTable.PSVersion -and $PSVersionTable.PSVersion.Major -ge 5

function Safe-WMI { param([string]$Class,$ns="root\cimv2")
  try { if($PSVersionOK){Get-CimInstance -ClassName $Class -Namespace $ns -ErrorAction Stop}else{Get-WmiObject -Class $Class -Namespace $ns -ErrorAction Stop} } catch{$null}
}

$devices = @()

# ========== 1. USB控制器与Hub ==========
$usbControllers = @(Safe-WMI Win32_USBController)
foreach ($c in $usbControllers) {
  $devices += @{
    type = "USBController"
    name = if ($c.Name) { ($c.Name -replace '\s+', ' ').Trim() } else { "USB Controller" }
    manufacturer = if ($c.Manufacturer) { $c.Manufacturer.Trim() } else { "" }
    deviceID = if ($c.DeviceID) { $c.DeviceID.Trim() } else { "" }
    status = if ($c.Status) { $c.Status.Trim() } else { "OK" }
  }
}

$usbHubs = @(Safe-WMI Win32_USBHub)
foreach ($h in $usbHubs) {
  $devices += @{
    type = "USBHub"
    name = if ($h.Name) { ($h.Name -replace '\s+', ' ').Trim() } else { "USB Hub" }
    manufacturer = ""
    deviceID = if ($h.DeviceID) { $h.DeviceID.Trim() } else { "" }
    status = if ($h.Status) { $h.Status.Trim() } else { "OK" }
  }
}

# ========== 2. PnP设备（键盘/鼠标/摄像头/蓝牙等） ==========
$pnpDevices = @(Safe-WMI Win32_PnPEntity)
$deviceClasses = @{
  "Keyboard" = @()
  "Mouse" = @()
  "Camera" = @()
  "Bluetooth" = @()
  "SmartCardReader" = @()
  "Biometric" = @()
  "Audio" = @()
  "Unknown" = @()
}

foreach ($d in $pnpDevices) {
  $name = if ($d.Name) { ($d.Name -replace '\s+', ' ').Trim() } else { "" }
  $desc = if ($d.Description) { $d.Description.Trim() } else { "" }
  $pnpClass = if ($d.PNPClass) { $d.PNPClass.Trim() } else { "" }
  $deviceID = if ($d.DeviceID) { $d.DeviceID.Trim() } else { "" }
  $status = if ($d.Status) { $d.Status.Trim() } else { "OK" }
  
  if (-not $name) { continue }
  
  $n = $name.ToLower()
  $c = $pnpClass.ToLower()
  
  if ($c -eq "keyboard" -or $n -match "keyboard|键盘") { 
    $deviceClasses["Keyboard"] += @{name=$name;desc=$desc;deviceID=$deviceID;status=$status}
  }
  elseif ($c -eq "mouse" -or $n -match "mouse|鼠标|touchpad|触控板") { 
    $deviceClasses["Mouse"] += @{name=$name;desc=$desc;deviceID=$deviceID;status=$status}
  }
  elseif ($c -eq "camera" -or $c -eq "image" -or $n -match "camera|摄像头|webcam") { 
    $deviceClasses["Camera"] += @{name=$name;desc=$desc;deviceID=$deviceID;status=$status}
  }
  elseif ($c -eq "bluetooth" -or $n -match "bluetooth|蓝牙") { 
    $deviceClasses["Bluetooth"] += @{name=$name;desc=$desc;deviceID=$deviceID;status=$status}
  }
  elseif ($c -eq "smartcardreader" -or $n -match "smart.?card|智能卡") { 
    $deviceClasses["SmartCardReader"] += @{name=$name;desc=$desc;deviceID=$deviceID;status=$status}
  }
  elseif ($c -eq "biometric" -or $n -match "fingerprint|指纹|face|人脸|ir.?camera") { 
    $deviceClasses["Biometric"] += @{name=$name;desc=$desc;deviceID=$deviceID;status=$status}
  }
  elseif ($c -in @("media","audioendpoint","sound") -or $n -match "audio|speaker|microphone|麦克风|扬声器|耳机|headphone") { 
    $deviceClasses["Audio"] += @{name=$name;desc=$desc;deviceID=$deviceID;status=$status}
  }
  else {
    $deviceClasses["Unknown"] += @{name=$name;desc=$desc;deviceID=$deviceID;status=$status}
  }
}

foreach ($cls in $deviceClasses.Keys) {
  foreach ($item in $deviceClasses[$cls]) {
    $devices += @{
      type = $cls
      name = $item.name
      description = $item.desc
      deviceID = $item.deviceID
      status = $item.status
    }
  }
}

# ========== 3. USB存储设备 ==========
$usbStorage = @()
try {
  $diskDrives = @(Safe-WMI Win32_DiskDrive)
  foreach ($d in $diskDrives) {
    if ($d.InterfaceType -eq "USB" -or $d.MediaType -match "External|Removable") {
      $usbStorage += @{
        model = ($d.Model -replace '\s+', ' ').Trim()
        sizeGB = if ($d.Size) { [math]::Round($d.Size/1073741824, 2) } else { 0 }
        interface = $d.InterfaceType
        media = $d.MediaType
        serial = if ($d.SerialNumber) { $d.SerialNumber.Trim() } else { "" }
        partitions = $d.Partitions
      }
    }
  }
} catch {}

# ========== 4. 扫描仪/图像设备 ==========
$scanners = @()
try {
  $imgDevices = @(Safe-WMI Win32_PnPEntity | Where-Object { $_.PNPClass -eq "Image" -or $_.PNPClass -eq "Scanner" })
  foreach ($s in $imgDevices) {
    $scanners += @{
      name = if ($s.Name) { ($s.Name -replace '\s+', ' ').Trim() } else { "Scanner" }
      deviceID = if ($s.DeviceID) { $s.DeviceID.Trim() } else { "" }
      status = if ($s.Status) { $s.Status.Trim() } else { "OK" }
    }
  }
} catch {}

# ========== 5. 串口/并口设备 ==========
$comPorts = @()
try {
  $serialPorts = @(Safe-WMI Win32_SerialPort)
  foreach ($sp in $serialPorts) {
    $comPorts += @{
      name = if ($sp.Name) { ($sp.Name -replace '\s+', ' ').Trim() } else { "COM Port" }
      deviceID = if ($sp.DeviceID) { $sp.DeviceID.Trim() } else { "" }
      baudRate = if ($sp.MaxBaudRate) { $sp.MaxBaudRate } else { 0 }
      status = if ($sp.Status) { $sp.Status.Trim() } else { "OK" }
    }
  }
} catch {}

# ========== 汇总输出 ==========
$categorySummary = @{}
foreach ($d in $devices) {
  $t = $d.type
  if (-not $categorySummary.ContainsKey($t)) { $categorySummary[$t] = 0 }
  $categorySummary[$t]++
}

$out = @{
  scanTime = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
  hostname = $env:COMPUTERNAME
  summary = @{
    totalDevices = $devices.Count
    byCategory = $categorySummary
    usbStorageCount = $usbStorage.Count
    scannerCount = $scanners.Count
    comPortCount = $comPorts.Count
  }
  usbStorage = $usbStorage
  scanners = $scanners
  comPorts = $comPorts
  devices = $devices
}

$json = $out | ConvertTo-Json -Depth 5 -Compress
if ($OutputPath) {
  [IO.File]::WriteAllText($OutputPath, $json, [Text.Encoding]::UTF8)
  Write-Host "OK:$OutputPath"
} else {
  Write-Output $json
}
