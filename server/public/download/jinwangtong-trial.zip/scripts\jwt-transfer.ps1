<#
.SYNOPSIS  金网通文件传输 PowerShell 包装器
.DESCRIPTION
  封装 jwt-transfer.exe，提供设备发现、发送、接收的 PowerShell 接口。
  可被 wizard-gui.ps1、console.ps1、agent.ps1 直接调用。

  依赖：本脚本所在目录下的 jwt-transfer.exe（由 jwt-transfer/ 项目编译产出）
  如未找到，自动尝试从 scripts/jwt-transfer/ 查找。

.EXAMPLE
  # 扫描局域网可传输设备
  .\jwt-transfer.ps1 -Discover

  # 接收模式（监听等待）
  .\jwt-transfer.ps1 -Receive -Port 53317 -SaveDir "C:\JinWangTongShare"

  # 发送文件到指定设备
  .\jwt-transfer.ps1 -Send -Target 192.168.1.100:53317 -Files "C:\report.xlsx","C:\photo.jpg"
#>
[CmdletBinding()]
param(
    [switch]$Discover,
    [switch]$Receive,
    [switch]$Send,
    [string]$Target,          # 目标 ip:port
    [string[]]$Files,         # 待发送文件
    [int]$Port = 53317,
    [string]$SaveDir = "C:\JinWangTongShare",
    [string]$Token,           # PAKE 配对口令
    [switch]$UseHTTP,
    [int]$TimeoutSec = 5
)

# 定位 jwt-transfer.exe
$scriptRoot = $PSScriptRoot
$exe = Join-Path $scriptRoot "jwt-transfer.exe"
if (-not (Test-Path $exe)) {
    # 尝试 scripts/jwt-transfer/ 子目录
    $exe = Join-Path $scriptRoot "jwt-transfer\jwt-transfer.exe"
}
if (-not (Test-Path $exe)) {
    # 尝试上级目录
    $exe = Join-Path (Split-Path $scriptRoot -Parent) "jwt-transfer\jwt-transfer.exe"
}
if (-not (Test-Path $exe)) {
    Write-Error "未找到 jwt-transfer.exe。请先编译 jwt-transfer 项目。"
    Write-Output "  搜索路径: $scriptRoot"
    Write-Output "  编译命令: cd ..\..\jwt-transfer && go build -o jwt-transfer.exe ."
    exit 1
}

$args = @()
$label = ""

if ($Discover) {
    $label = "设备发现"
    if ($TimeoutSec) { $args += "--timeout=${TimeoutSec}s" }
    & $exe discover @args
    exit $LASTEXITCODE
}

if ($Receive) {
    $label = "接收服务"
    $args += "--port=$Port"
    if ($SaveDir) { $args += "--dir=$SaveDir" }
    if ($UseHTTP) { $args += "--http" }
    if ($Token) { $args += "--token=$Token" }
    & $exe receive @args
    exit $LASTEXITCODE
}

if ($Send) {
    $label = "文件发送"
    if (-not $Target) { Write-Error "发送模式需要 -Target 参数"; exit 1 }
    if (-not $Files -or $Files.Count -eq 0) { Write-Error "发送模式需要 -Files 参数"; exit 1 }

    $args += "--target=$Target"
    if ($UseHTTP) { $args += "--http" }
    if ($Token) { $args += "--token=$Token" }
    $args += $Files

    Write-Host "文件传输: $($Files.Count) 个文件 → $Target" -ForegroundColor Cyan
    & $exe send @args
    exit $LASTEXITCODE
}

Write-Host "金网通文件传输 v1.0" -ForegroundColor Green
Write-Host "  用法: .\jwt-transfer.ps1 -Discover | -Receive | -Send" -ForegroundColor Cyan
Write-Host "  二进制: $exe" -ForegroundColor DarkGray

# 导出函数供其他脚本调用
function Start-JWTReceive {
    param([int]$Port=53317, [string]$Dir="C:\JinWangTongShare", [string]$Token="")
    $a = @($exe, "receive", "--port=$Port", "--dir=$Dir")
    if ($Token) { $a += "--token=$Token" }
    & $exe receive @a
}

function Send-JWTFile {
    param([string]$Target, [string[]]$Files, [string]$Token="")
    $a = @($exe, "send", "--target=$Target")
    if ($Token) { $a += "--token=$Token" }
    $a += $Files
    & $exe send @a
}

function Find-JWTDevices {
    param([int]$Timeout=5)
    & $exe discover "--timeout=${Timeout}s"
}
