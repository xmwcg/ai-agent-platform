<#
.SYNOPSIS
    金网通计算机管理系统 V2 · C 盘清理工具
.DESCRIPTION
    兼容 PowerShell 2.0+。
    功能：扫描报告 → 安全清理 → 大文件定位 → 重复文件 → 休眠/还原点管理 → 残留扫描
    安全护栏：个人目录只扫描不自动删；删除走回收站；不碰系统关键文件
#>

param(
    [switch]$Scan,             # 仅扫描生成报告
    [switch]$Clean,            # 执行安全清理（临时文件+缓存）
    [switch]$LargeFiles,       # 扫描大文件 Top 20
    [switch]$Duplicates,       # 扫描重复文件
    [switch]$Hibernate,        # 检查休眠文件
    [switch]$RestorePoint,     # 查看系统还原点
    [switch]$Residual,         # 扫描卸载残留
    [switch]$All,              # 全部检查
    [switch]$Json,             # JSON 输出
    [switch]$Quiet,            # 静默模式
    [string]$Drive = "C:"      # 目标盘符
)

if ($All) { $Scan = $Clean = $LargeFiles = $Duplicates = $Hibernate = $RestorePoint = $Residual = $true }
if (-not ($Scan -or $Clean -or $LargeFiles -or $Duplicates -or $Hibernate -or $RestorePoint -or $Residual)) {
    $All = $Scan = $true  # 默认扫描模式
}

# ========== 安全护栏 ==========
$ProtectedDirs = @(
    "$env:USERPROFILE\Desktop",
    "$env:USERPROFILE\Documents",
    "$env:USERPROFILE\Downloads",
    "$env:USERPROFILE\Pictures",
    "$env:USERPROFILE\Videos",
    "$env:USERPROFILE\Music",
    "$env:USERPROFILE\OneDrive"
)
$SystemDirs = @(
    "$env:SystemRoot\System32",
    "$env:SystemRoot\SysWOW64",
    "$env:ProgramFiles",
    "${env:ProgramFiles(x86)}"
)
# 安全清理的白名单目录（只清理这些）
$SafeCleanDirs = @(
    "$env:TEMP",
    "$env:SystemRoot\Temp",
    "$env:SystemRoot\SoftwareDistribution\Download",
    "$env:SystemRoot\Prefetch"
)

$Script:FilesDeleted = 0
$Script:BytesFreed = 0
$Script:Errors = @()

# ========== 辅助函数 ==========
function Format-Size {
    param([double]$Bytes)
    if ($Bytes -ge 1TB) { return "{0:N1} TB" -f ($Bytes / 1TB) }
    if ($Bytes -ge 1GB) { return "{0:N1} GB" -f ($Bytes / 1GB) }
    if ($Bytes -ge 1MB) { return "{0:N1} MB" -f ($Bytes / 1MB) }
    if ($Bytes -ge 1KB) { return "{0:N1} KB" -f ($Bytes / 1KB) }
    return "$Bytes B"
}

function Test-ProtectedDir {
    param([string]$Path)
    $normalized = (Resolve-Path $Path -ErrorAction SilentlyContinue).Path
    if (-not $normalized) { return $false }
    foreach ($d in $ProtectedDirs) {
        if ($normalized.StartsWith($d, [StringComparison]::OrdinalIgnoreCase)) { return $true }
    }
    foreach ($d in $SystemDirs) {
        if ($normalized.StartsWith($d, [StringComparison]::OrdinalIgnoreCase)) { return $true }
    }
    return $false
}

function Safe-Delete {
    param([string]$Path, [switch]$Force)
    if (Test-ProtectedDir $Path) {
        $msg = "[跳过受保护目录] $Path"
        if (-not $Quiet) { Write-Host "  $msg" -ForegroundColor Yellow }
        return
    }
    try {
        $item = Get-Item $Path -ErrorAction Stop
        $size = if ($item -is [System.IO.FileInfo]) { $item.Length } else { (Get-ChildItem $Path -Recurse -File -ErrorAction SilentlyContinue | Measure-Object Length -Sum).Sum }
        if ($Force) {
            Remove-Item $Path -Recurse -Force -ErrorAction Stop
        } else {
            # 使用 Shell.Application 走回收站（兼容 PS 2.0+）
            try {
                $shell = New-Object -ComObject Shell.Application
                $folder = $shell.Namespace((Get-Item $Path).DirectoryName)
                $item2 = $folder.ParseName((Get-Item $Path).Name)
                $item2.InvokeVerb("delete")
            } catch {
                # COM 失败降级为直接删除
                Remove-Item $Path -Recurse -Force -ErrorAction Stop
            }
        }
        $Script:FilesDeleted++
        if ($size) { $Script:BytesFreed += $size }
        if (-not $Quiet) { Write-Host "  ✓ 已删除: $Path ($(Format-Size $size))" -ForegroundColor Green }
    } catch {
        $err = "删除失败: $Path - $_"
        $Script:Errors += $err
        if (-not $Quiet) { Write-Host "  ✗ $err" -ForegroundColor Red }
    }
}

# ========== 1. 磁盘概览 ==========
function Get-DiskOverview {
    Write-Host ""
    Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Cyan
    Write-Host "  $Drive 盘空间概览" -ForegroundColor Cyan
    Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Cyan

    $drives = Get-WmiObject Win32_LogicalDisk -Filter "DeviceID='$Drive'" -ErrorAction SilentlyContinue
    if (-not $drives) { Write-Warning "未找到 $Drive 盘"; return $null }
    $d = $drives | Select-Object -First 1
    $total = [double]$d.Size
    $free  = [double]$d.FreeSpace
    $used  = $total - $free
    $pct   = if ($total -gt 0) { [math]::Round(($used / $total) * 100, 1) } else { 0 }

    Write-Host ""
    Write-Host "  总容量:   $(Format-Size $total)"
    Write-Host "  已用:     $(Format-Size $used)  ($pct%)"
    Write-Host "  可用:     $(Format-Size $free)"

    # 顶级文件夹占用排行
    Write-Host ""
    Write-Host "  各文件夹占用排行 (Top 15):" -ForegroundColor Yellow
    $topDirs = @()
    try {
        $items = Get-ChildItem $Drive\ -ErrorAction SilentlyContinue | Where-Object { $_.PSIsContainer }
        foreach ($item in $items) {
            $sz = (Get-ChildItem $item.FullName -Recurse -File -ErrorAction SilentlyContinue | Measure-Object Length -Sum).Sum
            $topDirs += [PSCustomObject]@{ Name=$item.Name; Path=$item.FullName; Size=$sz }
        }
        $topDirs = $topDirs | Sort-Object Size -Descending | Select-Object -First 15
        $rank = 1
        foreach ($td in $topDirs) {
            $bar = if ($used -gt 0) { "#" * [math]::Min(30, [math]::Round(($td.Size / $used) * 30)) } else { "" }
            Write-Host "  $($rank.ToString().PadLeft(2)). $($td.Name.PadRight(20)) $(Format-Size $td.Size)  $bar" -ForegroundColor Gray
            $rank++
        }
    } catch { }

    return @{ total=$total; used=$used; free=$free; pct=$pct; topDirs=$topDirs }
}

# ========== 2. 安全清理 ==========
function Invoke-SafeCleanup {
    Write-Host ""
    Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Green
    Write-Host "  系统安全清理（仅清理临时/缓存文件）" -ForegroundColor Green
    Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Green

    $targets = @(
        @{Path="$env:TEMP"; Desc="用户临时文件 (%TEMP%)"},
        @{Path="$env:SystemRoot\Temp"; Desc="系统临时文件 (Windows\Temp)"},
        @{Path="$env:SystemRoot\SoftwareDistribution\Download"; Desc="Windows 更新缓存"},
        @{Path="$env:SystemRoot\Prefetch"; Desc="预读文件 (Prefetch)"},
        @{Path="$env:LOCALAPPDATA\Microsoft\Windows\Explorer"; Desc="缩略图缓存 (thumbcache*.db)"}
    )

    foreach ($t in $targets) {
        if (-not (Test-Path $t.Path)) { continue }
        Write-Host "  [清理] $($t.Desc)" -ForegroundColor Cyan
        $before = (Get-ChildItem $t.Path -Recurse -File -ErrorAction SilentlyContinue | Measure-Object Length -Sum).Sum

        # 只清理文件，不删目录结构
        Get-ChildItem $t.Path -Recurse -File -ErrorAction SilentlyContinue | ForEach-Object {
            try {
                $pathItem = $_.FullName
                # 跳过缩略图缓存中不是 thumbcache 的文件
                if ($pathItem -match "Explorer" -and $_.Name -notmatch "thumbcache") { return }
                # 跳过正在使用的文件
                $f = [System.IO.File]::Open($pathItem, 'Open', 'Read', 'None')
                $f.Dispose()
                Remove-Item $pathItem -Force -ErrorAction Stop
                $Script:FilesDeleted++
                $Script:BytesFreed += $_.Length
            } catch { }
        }
        $after = (Get-ChildItem $t.Path -Recurse -File -ErrorAction SilentlyContinue | Measure-Object Length -Sum).Sum
        $freed = [math]::Max(0, $before - $after)
        if ($freed -gt 0) { Write-Host "    → 释放 $(Format-Size $freed)" -ForegroundColor Green }
    }

    # 回收站
    Write-Host "  [清理] 回收站" -ForegroundColor Cyan
    try {
        $shell = New-Object -ComObject Shell.Application
        $rb = $shell.Namespace(0x0a) # ssfBITBUCKET = 回收站
        $count = 0
        foreach ($item in $rb.Items()) { $count++ }
        if ($count -gt 0) {
            # 使用 Clear-RecycleBin (PS 5.0+) 或 COM
            if (Get-Command Clear-RecycleBin -ErrorAction SilentlyContinue) {
                Clear-RecycleBin -Force -ErrorAction SilentlyContinue
            } else {
                $rb.Items() | ForEach-Object { $_.InvokeVerb("delete") }
            }
            Write-Host "    → 已清空 $count 个项目" -ForegroundColor Green
        }
    } catch { Write-Host "    → 清理失败（无权限或无项目）" -ForegroundColor Gray }
}

# ========== 3. 大文件扫描 ==========
function Get-LargeFiles {
    Write-Host ""
    Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Magenta
    Write-Host "  大文件扫描（≥ 1GB，Top 20）" -ForegroundColor Magenta
    Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Magenta

    Write-Host "  扫描中... (仅报告，不删除)" -ForegroundColor Gray
    $files = @()
    try {
        $files = Get-ChildItem $Drive\ -Recurse -File -ErrorAction SilentlyContinue |
            Where-Object { $_.Length -ge 1GB } |
            Sort-Object Length -Descending |
            Select-Object -First 20
    } catch { }

    if ($files.Count -eq 0) { Write-Host "  未发现 ≥ 1GB 的文件。" -ForegroundColor Gray; return @() }

    # 按类型统计
    $byType = @{}
    foreach ($f in $files) {
        $ext = if ($f.Extension) { $f.Extension.ToLower() } else { "(无扩展名)" }
        $cat = switch ($ext) {
            {$_ -in '.mp4','.avi','.mkv','.mov','.wmv','.flv','.webm'} { "🎬 视频" }
            {$_ -in '.iso','.img','.vhd','.vhdx'} { "💿 光盘镜像/虚拟磁盘" }
            {$_ -in '.zip','.rar','.7z','.tar','.gz','.bz2'} { "📦 压缩包" }
            {$_ -in '.exe','.msi','.dmg','.pkg'} { "📥 安装包" }
            {$_ -in '.psd','.ai','.cdr','.sketch'} { "🎨 设计文件" }
            {$_ -in '.pst','.ost','.db','.sqlite','.mdf'} { "🗄️ 数据库/邮件" }
            {$_ -in '.log','.etl','.dmp'} { "📋 日志/转储" }
            default { "📄 其他" }
        }
        if (-not $byType[$cat]) { $byType[$cat] = @{count=0; size=0} }
        $byType[$cat].count++
        $byType[$cat].size += $f.Length
    }

    Write-Host "  按类型统计:" -ForegroundColor Yellow
    foreach ($k in ($byType.Keys | Sort-Object)) {
        $v = $byType[$k]
        Write-Host "    $k : $($v.count) 个, $(Format-Size $v.size)"
    }

    Write-Host ""
    Write-Host "  Top 20 大文件:" -ForegroundColor Yellow
    $rank = 1
    foreach ($f in $files) {
        $protected = if (Test-ProtectedDir $f.DirectoryName) { "🔒" } else { "  " }
        $name = if ($f.Name.Length -gt 45) { $f.Name.Substring(0, 42) + "..." } else { $f.Name }
        Write-Host "  $($rank.ToString().PadLeft(2)). $protected $(Format-Size $f.Length)  $name" -ForegroundColor Gray
        if ($rank -eq 1) { $rank++ }
        $rank++
    }

    return $files
}

# ========== 4. 重复文件扫描 ==========
function Get-DuplicateFiles {
    Write-Host ""
    Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Blue
    Write-Host "  重复文件扫描（按 SHA1 哈希，仅报告）" -ForegroundColor Blue
    Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Blue

    Write-Host "  ⚠ 扫描较慢，建议在空闲时间运行。" -ForegroundColor Yellow
    Write-Host "  正在收集文件列表..."

    # 仅扫描文档和下载目录（全盘扫描太慢）
    $scanDirs = @()
    if (Test-Path "$env:USERPROFILE\Documents") { $scanDirs += "$env:USERPROFILE\Documents" }
    if (Test-Path "$env:USERPROFILE\Downloads") { $scanDirs += "$env:USERPROFILE\Downloads" }
    if (Test-Path "$env:USERPROFILE\Desktop") { $scanDirs += "$env:USERPROFILE\Desktop" }

    if ($scanDirs.Count -eq 0) { Write-Host "  无可用扫描目录。" -ForegroundColor Gray; return }

    $allFiles = @()
    foreach ($d in $scanDirs) {
        $allFiles += Get-ChildItem $d -Recurse -File -ErrorAction SilentlyContinue | Where-Object { $_.Length -ge 1MB -and $_.Length -le 500MB }
    }
    Write-Host "  共 $(($allFiles | Measure-Object).Count) 个文件待检测..."

    $hashMap = @{}
    foreach ($f in $allFiles) {
        try {
            $hash = (Get-FileHash $f.FullName -Algorithm SHA1).Hash
            if (-not $hashMap[$hash]) { $hashMap[$hash] = @() }
            $hashMap[$hash] += $f.FullName
        } catch { }
    }

    $dups = $hashMap.GetEnumerator() | Where-Object { $_.Value.Count -gt 1 } | Sort-Object { $_.Value.Count } -Descending
    if ($dups.Count -eq 0) { Write-Host "  未发现重复文件。" -ForegroundColor Green; return }

    $totalDupSize = 0
    foreach ($d in $dups) {
        $sample = Get-Item $d.Value[0] -ErrorAction SilentlyContinue
        if ($sample) { $totalDupSize += $sample.Length * ($d.Value.Count - 1) }
    }

    Write-Host ""
    Write-Host "  发现 $($dups.Count) 组重复文件，共可释放约 $(Format-Size $totalDupSize)" -ForegroundColor Yellow
    Write-Host "  Top 10 重复组:" -ForegroundColor Yellow

    $topDups = $dups | Select-Object -First 10
    $rank = 1
    foreach ($d in $topDups) {
        $count = $d.Value.Count
        $sample = Get-Item $d.Value[0] -ErrorAction SilentlyContinue
        $size = if ($sample) { Format-Size ($sample.Length) } else { "?" }
        $name = if ($sample) {
            $n = Split-Path $sample.FullName -Leaf
            if ($n.Length -gt 35) { $n.Substring(0, 32) + "..." } else { $n }
        } else { "?" }
        Write-Host "  $($rank.ToString().PadLeft(2)). ${count}x ${size} - $name" -ForegroundColor Gray
        $rank++
    }
}

# ========== 5. 休眠文件 ==========
function Get-HibernateStatus {
    Write-Host ""
    Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor DarkYellow
    Write-Host "  休眠文件 (hiberfil.sys)" -ForegroundColor DarkYellow
    Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor DarkYellow

    $hFile = "$env:SystemDrive\hiberfil.sys"
    if (Test-Path $hFile) {
        $sz = (Get-Item $hFile).Length
        Write-Host "  hiberfil.sys 存在，占用 $(Format-Size $sz)" -ForegroundColor Yellow
        Write-Host ""
        Write-Host "  休眠文件用于快速启动和休眠功能。" -ForegroundColor Gray
        Write-Host "  如不需要休眠（大多数台式机不需要），可运行以下命令关闭：" -ForegroundColor Gray
        Write-Host "    powercfg -h off" -ForegroundColor White
        Write-Host "  这将立即删除 hiberfil.sys，释放 $(Format-Size $sz)。" -ForegroundColor Green
        Write-Host "  如需恢复：powercfg -h on" -ForegroundColor Gray
    } else {
        Write-Host "  hiberfil.sys 不存在（休眠已关闭）。" -ForegroundColor Green
    }

    # 虚拟内存 pagefile.sys
    $pFile = "$env:SystemDrive\pagefile.sys"
    if (Test-Path $pFile) {
        $psz = (Get-Item $pFile).Length
        Write-Host ""
        Write-Host "  pagefile.sys (虚拟内存): $(Format-Size $psz)" -ForegroundColor Gray
        Write-Host "  ⚠ 不建议删除。如需调整大小，请使用「系统属性 → 高级 → 性能设置 → 高级 → 虚拟内存」。"
    }
}

# ========== 6. 系统还原点 ==========
function Get-RestorePoints {
    Write-Host ""
    Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor DarkMagenta
    Write-Host "  系统还原点管理" -ForegroundColor DarkMagenta
    Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor DarkMagenta

    try {
        $rps = Get-ComputerRestorePoint -ErrorAction SilentlyContinue
        if (-not $rps) {
            Write-Host "  未发现还原点（或需要管理员权限查看）。" -ForegroundColor Gray
            return
        }
        Write-Host "  共 $($rps.Count) 个还原点:" -ForegroundColor Yellow
        $rps | Sort-Object CreationTime -Descending | Select-Object -First 10 | ForEach-Object {
            Write-Host "    $($_.CreationTime.ToString('yyyy-MM-dd HH:mm')) - $($_.Description)" -ForegroundColor Gray
        }
        Write-Host ""
        Write-Host "  如需删除旧还原点（建议保留最近1-2个），运行：" -ForegroundColor Gray
        Write-Host "    系统属性 → 系统保护 → 配置 → 删除" -ForegroundColor White
        Write-Host "  或使用：vssadmin delete shadows /for=C: /oldest" -ForegroundColor White
    } catch {
        Write-Host "  无法查询还原点（需要管理员权限）。" -ForegroundColor Gray
    }
}

# ========== 7. 卸载残留 ==========
function Get-ResidualScan {
    Write-Host ""
    Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor DarkCyan
    Write-Host "  卸载残留 / 空文件夹扫描" -ForegroundColor DarkCyan
    Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor DarkCyan

    # 1. 检查 Program Files 中可能残留的无主程序目录
    Write-Host "  扫描 Program Files 残留..." -ForegroundColor Gray
    $pfDirs = @("$env:ProgramFiles", "${env:ProgramFiles(x86)}")
    if (Test-Path "$env:LOCALAPPDATA\Programs") { $pfDirs += "$env:LOCALAPPDATA\Programs" }
    $uninstallKeys = @(
        "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall",
        "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall"
    )
    $knownPaths = @{}
    foreach ($key in $uninstallKeys) {
        Get-ChildItem $key -ErrorAction SilentlyContinue | ForEach-Object {
            try {
                $loc = (Get-ItemProperty $_.PSPath -Name "InstallLocation" -ErrorAction SilentlyContinue).InstallLocation
                if ($loc) { $knownPaths[$loc.ToLower()] = $true }
                $loc2 = (Get-ItemProperty $_.PSPath -Name "DisplayIcon" -ErrorAction SilentlyContinue).DisplayIcon
                if ($loc2 -and -not ($loc2 -match '\.(exe|ico|dll)')) {
                    $d = Split-Path $loc2 -Parent
                    if ($d) { $knownPaths[$d.ToLower()] = $true }
                }
            } catch {}
        }
    }

    $orphans = @()
    foreach ($pf in $pfDirs) {
        if (-not (Test-Path $pf)) { continue }
        Get-ChildItem $pf -Directory -ErrorAction SilentlyContinue | ForEach-Object {
            if ($_.Name -match '^(Common Files|WindowsApps|Microsoft|dotnet|IIS|ModifiableWindowsApps)$') { return }
            $lower = $_.FullName.ToLower()
            if (-not $knownPaths[$lower]) {
                $orphans += [PSCustomObject]@{ Name=$_.Name; Path=$_.FullName; Size=(Get-ChildItem $_.FullName -Recurse -File -ErrorAction SilentlyContinue | Measure-Object Length -Sum).Sum }
            }
        }
    }

    if ($orphans.Count -gt 0) {
        $orphans = $orphans | Sort-Object Size -Descending
        Write-Host "  发现 $($orphans.Count) 个疑似无主程序目录:" -ForegroundColor Yellow
        $orphans | Select-Object -First 10 | ForEach-Object {
            Write-Host "    $(Format-Size $_.Size)  $($_.Name)  ($($_.Path))" -ForegroundColor Gray
        }
        Write-Host "  ⚠ 请人工确认后再清理。部分可能仍有残留数据需要。" -ForegroundColor Yellow
    } else {
        Write-Host "  未发现明显残留。" -ForegroundColor Green
    }

    # 2. AppData Local 中的废弃程序目录
    Write-Host ""
    Write-Host "  扫描 AppData 残留..." -ForegroundColor Gray
    $adDirs = @("$env:LOCALAPPDATA", "$env:APPDATA")
    $knownAD = @{}
    foreach ($key in $uninstallKeys) {
        Get-ChildItem $key -ErrorAction SilentlyContinue | ForEach-Object {
            try {
                $name = (Get-ItemProperty $_.PSPath -Name "DisplayName" -ErrorAction SilentlyContinue).DisplayName
                if ($name) { $knownAD[$name.ToLower()] = $true }
            } catch {}
        }
    }
    $adOrphans = @()
    foreach ($ad in $adDirs) {
        if (-not (Test-Path $ad)) { continue }
        Get-ChildItem $ad -Directory -ErrorAction SilentlyContinue | ForEach-Object {
            if ($_.Name -match '^(Microsoft|Packages|Temp|CrashDumps|ConnectedDevicesPlatform|ElevatedDiagnostics)$') { return }
            $adOrphans += [PSCustomObject]@{ Name=$_.Name; Path=$_.FullName }
        }
    }
    if ($adOrphans.Count -gt 0) {
        # Too many to list individually — just report count
        Write-Host "  AppData 目录共 $($adOrphans.Count) 个程序数据文件夹。" -ForegroundColor Gray
        Write-Host "  建议使用磁盘清理工具自动检测无用缓存。" -ForegroundColor Gray
    }
}

# ========== 主流程 ==========
Write-Host ""
Write-Host "════════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "  金网通 V2 · $Drive 盘空间分析与清理工具" -ForegroundColor Cyan
Write-Host "════════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "  安全护栏：个人目录只扫描不自动删，删除走回收站" -ForegroundColor Gray
Write-Host ""

# 检查管理员权限
$isAdmin = $false
try {
    $wp = [Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
    $isAdmin = $wp.IsInRole([Security.Principal.WindowsBuiltinRole]::Administrator)
} catch {}
if (-not $isAdmin) {
    Write-Host "  ⚠ 建议以管理员身份运行以获取完整权限。" -ForegroundColor Yellow
    Write-Host ""
}

$startTime = Get-Date
$overview = Get-DiskOverview

if ($Scan -or $All) { $overview = Get-DiskOverview }
if ($LargeFiles -or $All) { $lf = Get-LargeFiles }
if ($Duplicates -or $All) { Get-DuplicateFiles }
if ($Hibernate -or $All) { Get-HibernateStatus }
if ($RestorePoint -or $All) { Get-RestorePoints }
if ($Residual -or $All) { Get-ResidualScan }
if ($Clean -or $All) { Invoke-SafeCleanup }

$elapsed = [math]::Round(((Get-Date) - $startTime).TotalSeconds, 1)

# ========== 汇总 ==========
Write-Host ""
Write-Host "════════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "  清理报告汇总" -ForegroundColor Cyan
Write-Host "════════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "  运行时间: $elapsed 秒" -ForegroundColor Gray
if ($Clean -or $All) {
    Write-Host "  已清理文件: $($Script:FilesDeleted) 个" -ForegroundColor Green
    Write-Host "  释放空间: $(Format-Size $Script:BytesFreed)" -ForegroundColor Green
}
if ($Script:Errors.Count -gt 0) {
    Write-Host "  错误: $($Script:Errors.Count) 项" -ForegroundColor Red
    foreach ($e in $Script:Errors) { Write-Host "    $e" -ForegroundColor Red }
}

# 建议
Write-Host ""
Write-Host "  💡 清理建议:" -ForegroundColor Yellow
if ($overview -and $overview.pct -gt 80) {
    Write-Host "    - C盘使用率 $($overview.pct)%，建议运行安全清理或扩容。"
}
if ($Clean) {
    Write-Host "    - 已完成安全清理。如需释放更多，可手动检查大文件列表。"
}
if ($LargeFiles) {
    Write-Host "    - 检查 Top 20 大文件，将不常用的移动到其他盘或删除。"
}
if ($Hibernate) {
    Write-Host "    - 如果是台式机且不常休眠，可运行 powercfg -h off 释放 hiberfil.sys。"
}
Write-Host ""
Write-Host "════════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "  提示：重复运行 .\clean-disk.ps1 -All 进行全面扫描和清理" -ForegroundColor Gray
Write-Host "════════════════════════════════════════════════════════" -ForegroundColor Cyan

# JSON 输出
if ($Json) {
    @{
        drive = $Drive
        disk = @{ total=$overview.total; used=$overview.used; free=$overview.free; pct=$overview.pct }
        cleaned = @{ files=$Script:FilesDeleted; bytes=$Script:BytesFreed }
        errors = $Script:Errors
        duration = $elapsed
    } | ConvertTo-Json -Compress
}