<#
.SYNOPSIS
    金网通计算机管理系统 V2 · 系统兼容检查工具
.DESCRIPTION
    检查当前系统环境是否满足金网通的运行要求。
    兼容 PowerShell 2.0+，自动检测 PS版本/OS/权限/网络/依赖。
    输出标准化 JSON 兼容报告。
#>

param(
    [switch]$Json,        # 输出JSON格式（机器可读）
    [switch]$Quiet,       # 静默模式：仅返回退出码（0=完全兼容, 1=部分兼容, 2=不兼容）
    [switch]$Detail       # 详细模式：输出每项检查的详情
)

$Report = @{
    compatible    = $true
    psVersion     = ""
    psVersionOk   = $true
    osVersion     = ""
    osVersionOk   = $true
    isAdmin       = $false
    networkOk     = $true
    winRMOk       = $false
    smbOk         = $false
    firewallOk    = $false
    netModulesOk   = $true
    issues        = @()
    suggestions   = @()
}

# ---------- 1. PowerShell 版本检测 ----------
try {
    $psv = $PSVersionTable.PSVersion
    $Report.psVersion = "$($psv.Major).$($psv.Minor)"
    if ($psv.Major -ge 5) {
        $Report.psVersionOk = $true
    } elseif ($psv.Major -ge 3) {
        $Report.psVersionOk = $true
        $Report.issues += "PowerShell $($psv.Major).$($psv.Minor) 版本较低，部分功能需要降级运行。建议升级到 5.1 或更高。"
        $Report.suggestions += "安装 WMF 5.1：https://www.microsoft.com/en-us/download/details.aspx?id=54616"
    } else {
        $Report.psVersionOk = $false
        $Report.compatible = $false
        $Report.issues += "PowerShell $($psv.Major) 版本过低（最低需 2.0）。请升级到 3.0 或更高。"
        $Report.suggestions += "安装 WMF 3.0+：https://www.microsoft.com/en-us/download/details.aspx?id=54616"
    }
} catch {
    $Report.psVersion = "未知(≤2.0)"
    $Report.psVersionOk = $false
    $Report.compatible = $false
}

# ---------- 2. 操作系统检测 ----------
try {
    $os = Get-WmiObject Win32_OperatingSystem -ErrorAction Stop
    $Report.osVersion = "$($os.Caption) ($($os.Version))"
    # Windows 7 (6.1) / 2008 R2 最低
    $ver = [version]$os.Version
    if ($ver.Major -ge 10) {
        $Report.osVersionOk = $true
    } elseif ($ver.Major -ge 6 -and $ver.Minor -ge 1) {
        $Report.osVersionOk = $true
        $Report.issues += "Windows $($ver.Major).$($ver.Minor) 版本较旧，建议升级到 Windows 10/11。"
    } else {
        $Report.osVersionOk = $false
        $Report.compatible = $false
        $Report.issues += "操作系统版本过低（最低需 Windows 7 / Server 2008 R2）。"
    }
} catch {
    $Report.osVersion = "未知"
    $Report.osVersionOk = $false
    $Report.compatible = $false
}

# ---------- 3. 管理员权限检测 ----------
try {
    $wp = [Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
    $Report.isAdmin = $wp.IsInRole([Security.Principal.WindowsBuiltinRole]::Administrator)
    if (-not $Report.isAdmin) {
        $Report.issues += "当前未以管理员权限运行。金网通大部分功能需要管理员权限。"
        $Report.suggestions += "右键 PowerShell →「以管理员身份运行」，或运行 perms-fix.ps1 自动提权。"
    }
} catch {
    $Report.isAdmin = $false
}

# ---------- 4. 网络连接检测 ----------
try {
    $ping = Test-Connection -ComputerName "8.8.8.8" -Count 1 -Quiet -ErrorAction SilentlyContinue
    if (-not $ping) {
        $ping = Test-Connection -ComputerName "www.baidu.com" -Count 1 -Quiet -ErrorAction SilentlyContinue
    }
    if (-not $ping) {
        $Report.networkOk = $false
        $Report.issues += "无法连接到互联网（8.8.8.8 / www.baidu.com 均不可达）。互联网功能将受限。"
    }
} catch {
    # PS 2.0 may not have Test-Connection
    try {
        $ping = New-Object System.Net.NetworkInformation.Ping
        $reply = $ping.Send("8.8.8.8", 3000)
        if ($reply.Status -ne 'Success') { $Report.networkOk = $false }
    } catch { $Report.networkOk = $false }
}

# ---------- 5. WinRM 检测 ----------
try {
    $srv = Get-Service -Name "WinRM" -ErrorAction SilentlyContinue
    if ($srv -and $srv.Status -eq 'Running') { $Report.winRMOk = $true }
    if (-not $Report.winRMOk) {
        $Report.issues += "WinRM 服务未运行。远程管理功能将不可用。"
        $Report.suggestions += "以管理员身份运行：Enable-PSRemoting -Force"
    }
} catch { $Report.winRMOk = $false }

# ---------- 6. SMB/文件共享检测 ----------
try {
    $smb = Get-Service -Name "LanmanServer" -ErrorAction SilentlyContinue
    if ($smb -and $smb.Status -eq 'Running') { $Report.smbOk = $true }
    if (-not $Report.smbOk) {
        $Report.issues += "SMB/文件共享服务未运行。文件共享功能将不可用。"
        $Report.suggestions += "以管理员身份运行：Set-Service LanmanServer -StartupType Automatic; Start-Service LanmanServer"
    }
} catch { }

# ---------- 7. 防火墙规则检测 ----------
try {
    if (Get-Command Get-NetFirewallRule -ErrorAction SilentlyContinue) {
        $fb = Get-NetFirewallRule -DisplayName "文件和打印机共享*" -ErrorAction SilentlyContinue
        if ($fb) { $Report.firewallOk = $true }
    }
    if (-not $Report.firewallOk) {
        try {
            # netsh fallback
            $ruleCheck = netsh advfirewall firewall show rule name="文件和打印机共享(回显请求 - ICMPv4-In)" 2>&1
            if ($ruleCheck -match "允许") { $Report.firewallOk = $true }
        } catch { }
    }
    if (-not $Report.firewallOk) {
        $Report.issues += "防火墙规则未允许文件和打印机共享。可能影响局域网发现和文件共享。"
    }
} catch { }

# ---------- 8. 网络管理模块检测 ----------
try {
    if (Get-Command Get-NetAdapter -ErrorAction SilentlyContinue) {
        $Report.netModulesOk = $true
    } elseif (Get-Module -ListAvailable -Name NetAdapter -ErrorAction SilentlyContinue) {
        $Report.netModulesOk = $true
    } else {
        # Available on PS 3.0+ with WMF install, not present on PS 2.0
        $Report.netModulesOk = $false
        if ($psv -and $psv.Major -lt 3) {
            $Report.issues += "网络管理模块(NetAdapter)不可用（PS 版本 < 3.0）。将使用 WMI 降级方式。"
        }
    }
} catch { }

# ---------- 输出 ----------
if ($Quiet) {
    if ($Report.compatible) { exit 0 }
    else { exit 2 }
}

if ($Json) {
    $Report | ConvertTo-Json -Compress
    exit
}

# --- 人性化控制台输出 ---
$Color = if ($Report.compatible) { "Green" } else { "Yellow" }
Write-Host ""
Write-Host "════════════════════════════════════════════════════════" -ForegroundColor $Color
Write-Host "  金网通 V2 · 系统兼容检查报告" -ForegroundColor $Color
Write-Host "════════════════════════════════════════════════════════" -ForegroundColor $Color
Write-Host ""
Write-Host "  PowerShell: $($Report.psVersion)  $(if($Report.psVersionOk){'✅'}else{'❌'})"
Write-Host "  操作系统:   $($Report.osVersion)  $(if($Report.osVersionOk){'✅'}else{'❌'})"
Write-Host "  管理员权限: $(if($Report.isAdmin){'✅ 已获取'}else{'⚠️ 未获取'})"
Write-Host "  网络连接:   $(if($Report.networkOk){'✅ 正常'}else{'⚠️ 不可达'})"
Write-Host "  WinRM远程:  $(if($Report.winRMOk){'✅ 已启用'}else{'⚠️ 未启用'})"
Write-Host "  SMB/共享:   $(if($Report.smbOk){'✅ 已启用'}else{'⚠️ 未启用'})"
Write-Host "  防火墙规则: $(if($Report.firewallOk){'✅ 已配置'}else{'⚠️ 未放行'})"
Write-Host "  网络模块:   $(if($Report.netModulesOk){'✅ 可用'}else{'⚠️ 有限'})"
Write-Host ""

if ($Report.compatible) {
    Write-Host "  ✅ 当前系统环境满足金网通运行要求。" -ForegroundColor Green
} else {
    Write-Host "  ❌ 当前系统环境部分不满足金网通要求。" -ForegroundColor Red
}

if ($Report.issues.Count -gt 0) {
    Write-Host ""
    Write-Host "  发现的问题：" -ForegroundColor Yellow
    foreach ($issue in $Report.issues) {
        Write-Host "    • $issue" -ForegroundColor Yellow
    }
}
if ($Report.suggestions.Count -gt 0) {
    Write-Host ""
    Write-Host "  建议：" -ForegroundColor Cyan
    foreach ($sug in $Report.suggestions) {
        Write-Host "    > $sug" -ForegroundColor Cyan
    }
}

if (-not $Report.isAdmin) {
    Write-Host ""
    Write-Host "  ┌─────────────────────────────────────────────────┐"
    Write-Host "  │ 温馨提示：请右键 PowerShell 选择                 │"
    Write-Host "  │ 「以管理员身份运行」后重试本检查。               │"
    Write-Host "  │ 或运行 .\perms-fix.ps1 自动提权修复。            │"
    Write-Host "  └─────────────────────────────────────────────────┘" -ForegroundColor Magenta
}

Write-Host ""
Write-Host "════════════════════════════════════════════════════════" -ForegroundColor $Color