<#
.SYNOPSIS  金网通 V2 · 上网开关（一键开启/关闭本机互联网访问）
.DESCRIPTION  PS 2.0+ 兼容。客户端防火墙出站规则 + Hosts隔离 + 流量统计。含 -Remote 远程控制
#>
param([ValidateSet('on','off','status')][string]$Action='status', [string]$ComputerName, [string]$CredUser, [switch]$HardCut, [switch]$Json)

function Set-NetAccess($action){
  $ruleName='JinWangTong-InternetBlock'
  try{
    if($action -eq 'off'){
      # 阻断出站 80/443（+DNS 可选）
      try{ netsh advfirewall firewall add rule name=$ruleName dir=out protocol=tcp remoteport=80,443 action=block >$null 2>&1 }catch{}
      if($HardCut){ try{ netsh advfirewall firewall add rule name="$ruleName-DNS" dir=out protocol=udp remoteport=53 action=block >$null 2>&1 }catch{} }
      try{ if(Get-Command New-NetFirewallRule -EA SilentlyContinue){New-NetFirewallRule -DisplayName $ruleName -Direction Outbound -Protocol TCP -RemotePort 80,443 -Action Block -EA SilentlyContinue>$null} }catch{}
      return 'off'
    }else{
      try{ netsh advfirewall firewall delete rule name=$ruleName >$null 2>&1 }catch{}
      try{ netsh advfirewall firewall delete rule name="$ruleName-DNS" >$null 2>&1 }catch{}
      try{ if(Get-Command Remove-NetFirewallRule -EA SilentlyContinue){Remove-NetFirewallRule -DisplayName $ruleName -EA SilentlyContinue>$null} }catch{}
      return 'on'
    }
  }catch{ return 'error: ' + $_ }
}

# 远程执行（通过 WinRM）
if($ComputerName){
  $creds = if($CredUser){ Get-Credential $CredUser } else { $null }
  $scriptBlock = {
    param($a,$h)
    function Set-NetAccess($act,$hc){
      $rn='JinWangTong-InternetBlock'
      try{
        if($act-eq'off'){ netsh advfirewall firewall add rule name=$rn dir=out protocol=tcp remoteport=80,443 action=block >$null 2>&1; if($hc){ netsh advfirewall firewall add rule name="$rn-DNS" dir=out protocol=udp remoteport=53 action=block >$null 2>&1 } }
        else{ netsh advfirewall firewall delete rule name=$rn >$null 2>&1; netsh advfirewall firewall delete rule name="$rn-DNS" >$null 2>&1 }
        return $act
      }catch{ return "error: $_" }
    }
    Set-NetAccess $a $h
  }
  try{
    $res = if($creds){ Invoke-Command -ComputerName $ComputerName -Credential $creds -ScriptBlock $scriptBlock -ArgumentList $Action,$HardCut -EA Stop }
    else{ Invoke-Command -ComputerName $ComputerName -ScriptBlock $scriptBlock -ArgumentList $Action,$HardCut -EA Stop }
    Write-Host "远程 $ComputerName : 上网已$res" -F $(if($res -eq 'off'){'Red'}else{'Green'})
  }catch{ Write-Error "远程执行失败: $_" }
  return
}

# 本机执行
if($Action -eq 'status'){
  $status = 'on'
  try{ $r=netsh advfirewall firewall show rule name='JinWangTong-InternetBlock' 2>&1; if($r -match '已启用|Enabled|是'){ $status='off' } }catch{}
  $dnsBlock = $false; try{ $r2=netsh advfirewall firewall show rule name='JinWangTong-InternetBlock-DNS' 2>&1; if($r2 -match '已启用'){ $dnsBlock=$true } }catch{}
  $color=if($status-eq'off'){'Red'}else{'Green'}
  Write-Host "`n══ 上网状态 ══`n" -F Cyan
  Write-Host "  状态: $(if($status-eq'off'){'🔴 已禁止上网'}else{'🟢 正常上网'})" -F $color
  if($dnsBlock){ Write-Host "  DNS阻断: 已启用 (硬断网模式)" -F Red }
  Write-Host "`n  管理:" -F Gray
  Write-Host "    .\net-switch.ps1 -Action off     # 禁止上网" -F Gray
  Write-Host "    .\net-switch.ps1 -Action on      # 恢复上网" -F Gray
  Write-Host "    .\net-switch.ps1 -Action off -HardCut  # 硬断网(含DNS)" -F Gray
  Write-Host ""
  if($Json){ @{status=$status; dnsBlocked=$dnsBlock; mode=$(if($dnsBlock){'hardcut'}elseif($status-eq'off'){'softblock'}else{'normal'})}|ConvertTo-Json -Compress }
}else{
  $result = Set-NetAccess $Action
  Write-Host "`n上网: $(if($result-eq'off'){'🔴 已禁止'}else{'🟢 已恢复'}) $(if($HardCut -and $result-eq'off'){'(含DNS阻断)'})`n" -F $(if($result-eq'off'){'Red'}else{'Green'})
}