<#
.SYNOPSIS  金网通 V2 · 打印机一键共享设置
.DESCRIPTION  PS 2.0+ 兼容。自动发现→共享→防火墙→测试页→客户端连接命令
#>
param([string]$PrinterName, [string]$ShareName, [switch]$List, [switch]$Share, [switch]$TestPage, [switch]$Json)

function wmi($c){try{if(Get-Command Get-CimInstance -EA SilentlyContinue){Get-CimInstance $c -EA Stop}else{Get-WmiObject $c -EA Stop}}catch{}}

# 列出所有打印机
if($List -or (-not $PrinterName -and -not $Share -and -not $TestPage)){
  Write-Host "`n══ 本机打印机列表 ══`n" -F Cyan
  $printers=@()
  try{if(Get-Command Get-Printer -EA SilentlyContinue){Get-Printer -EA SilentlyContinue|%{ $printers+=@{Name=$_.Name; Shared=$_.Shared; Port=$_.PortName; Driver=$_.DriverName; Default=$_.Default} }}}catch{}
  if($printers.Count -eq 0){try{wmi Win32_Printer|%{ $printers+=@{Name=$_.Name; Shared=$_.Shared; Port=$_.PortName; Driver=$_.DriverName; Default=$_.Default} }}catch{}}
  foreach($p in $printers){
    $s=if($p.Default){'⭐'}else{'🖨️'}; $sh=if($p.Shared){'[已共享]'}else{''}
    Write-Host "  $s $($p.Name) $sh" -F $(if($p.Default){'Yellow'}else{'White'})
    Write-Host "    驱动: $($p.Driver) | 端口: $($p.Port)" -F Gray
  }
  if($Json){($printers|ConvertTo-Json -Compress)}
  Write-Host "`n用法: .\printer-share.ps1 -PrinterName '打印机名' -Share" -F Gray
  Write-Host "      .\printer-share.ps1 -PrinterName '打印机名' -TestPage" -F Gray
  return
}

if(-not $PrinterName){ Write-Warning "请用 -PrinterName 指定打印机。用 -List 查看列表。"; return }

# 共享设置
if($Share){
  Write-Host "`n══ 设置打印机共享 ══`n" -F Green
  try{
    # 开放防火墙
    Write-Host " [1/3] 开放防火墙规则..." -F Cyan
    try{ netsh advfirewall firewall set rule group="文件和打印机共享" new enable=Yes >$null 2>&1 }catch{}
    try{ netsh advfirewall firewall set rule name="网络发现(NB-Name-In)" new enable=Yes >$null 2>&1 }catch{}
    Write-Host "   ✓ 防火墙规则已配置" -F Green

    # 共享打印机
    Write-Host " [2/3] 设置共享..." -F Cyan
    $shareN = if($ShareName){$ShareName}else{$PrinterName -replace '[\\/:*?"<>|]','_'}
    try{ if(Get-Command Set-Printer -EA SilentlyContinue){Set-Printer -Name $PrinterName -Shared $true -ShareName $shareN -EA Stop}else{ $p=wmi Win32_Printer|?{$_.Name -eq $PrinterName}|Select -First 1; if($p){$p.Shared=$true;$p.ShareName=$shareN;$p.Put()} } }catch{
      # net share fallback 对打印机用注册表
      $key="HKLM:\SYSTEM\CurrentControlSet\Control\Print\Printers\$PrinterName"
      Set-ItemProperty -Path $key -Name "Shared" -Value 1 -EA SilentlyContinue
    }
    Write-Host "   ✓ 打印机已共享: \\$env:COMPUTERNAME\$shareN" -F Green

    # 获取本机 IP 生成连接命令
    Write-Host " [3/3] 生成客户端连接命令..." -F Cyan
    $ip=''
    try{if(Get-Command Get-NetIPAddress -EA SilentlyContinue){ $ip=(Get-NetIPAddress -AddressFamily IPv4|?{$_.InterfaceAlias -notmatch 'Loopback'}|Select -First 1).IPAddress } }catch{
      try{ $ip=(wmi Win32_NetworkAdapterConfiguration|?{$_.IPEnabled}|Select -First 1).IPAddress[0] }catch{}
    }
    Write-Host ""
    Write-Host "  ┌─────────────────────────────────────────────────┐"
    Write-Host "  │ 其他电脑添加此打印机：                           │"
    Write-Host "  │                                                 │"
    Write-Host "  │ 方式1 (运行):  \\$env:COMPUTERNAME\$shareN" -F Yellow
    Write-Host "  │ 方式2 (命令行):                                 │"
    Write-Host "  │   rundll32 printui.dll,PrintUIEntry /in /n\\$env:COMPUTERNAME\$shareN" -F White
    Write-Host "  │                                                 │"
    Write-Host "  │ 复制上面一行到其他电脑的「运行」(Win+R) 即可     │"
    Write-Host "  └─────────────────────────────────────────────────┘" -F Green
    Write-Host ""

    if($Json){ @{computer=$env:COMPUTERNAME; printer=$PrinterName; share=$shareN; ip=$ip; uncPath="\\$env:COMPUTERNAME\$shareN"; command="rundll32 printui.dll,PrintUIEntry /in /n\\$env:COMPUTERNAME\$shareN"} | ConvertTo-Json -Compress }
  }catch{ Write-Error "共享失败: $_" }
}

# 打印测试页
if($TestPage){
  Write-Host "`n══ 打印测试页 ══`n" -F Yellow
  try{
    $printer = if(Get-Command Get-Printer -EA SilentlyContinue){Get-Printer -Name $PrinterName -EA Stop}else{wmi Win32_Printer|?{$_.Name -eq $PrinterName}|Select -First 1}
    if(-not $printer){ Write-Warning "打印机 '$PrinterName' 未找到"; return }
    # 使用 PrintUI 方式打印测试页（最兼容）
    $cmd = "rundll32 printui.dll,PrintUIEntry /k /n`"$PrinterName`""
    Start-Process cmd -ArgumentList "/c $cmd" -WindowStyle Hidden -Wait
    Write-Host "   ✓ 测试页已发送到 $PrinterName" -F Green
    Write-Host "   (如果未打印，请检查打印机是否开机/联机/有纸)" -F Gray
  }catch{ Write-Error "测试页打印失败: $_" }
}