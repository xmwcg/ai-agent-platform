<#
.SYNOPSIS  金网通 V2 · 完整硬件扫描引擎
.DESCRIPTION  PS 2.0+ 全兼容。自动降级 Get-CimInstance → Get-WmiObject。
  扫描项：CPU/主板/内存/硬盘/GPU/网卡/显示器/电源/BIOS/输入设备
  输出标准 JSON或人性化控制台报告
#>
param([switch]$Json, [switch]$Quiet)

$hw = @{}
function wmi($class) { try { if(Get-Command Get-CimInstance -EA SilentlyContinue){Get-CimInstance $class -EA Stop}else{Get-WmiObject $class -EA Stop} }catch{} }

# CPU
$cpu = wmi Win32_Processor | Select -First 1
$hw.cpu = @{ name=$cpu.Name; manufacturer=$cpu.Manufacturer; cores=$cpu.NumberOfCores; threads=$cpu.ThreadCount; maxSpeed=$cpu.MaxClockSpeed; sockets=$cpu.SocketDesignation; architecture=$cpu.Architecture }

# 主板
$mb = wmi Win32_BaseBoard | Select -First 1
$bios = wmi Win32_BIOS | Select -First 1
$hw.motherboard = @{ manufacturer=$mb.Manufacturer; product=$mb.Product; serial=$mb.SerialNumber; version=$mb.Version }
$hw.bios = @{ vendor=$bios.Manufacturer; version=$bios.SMBIOSBIOSVersion; releaseDate=$bios.ReleaseDate; serial=$bios.SerialNumber }

# 系统
$os = wmi Win32_OperatingSystem | Select -First 1
$cs = wmi Win32_ComputerSystem | Select -First 1
$hw.system = @{ manufacturer=$cs.Manufacturer; model=$cs.Model; serial=$bios.SerialNumber; totalRam=([math]::Round($cs.TotalPhysicalMemory/1GB,1)); osName=$os.Caption; osVersion=$os.Version; osArch=$os.OSArchitecture; installDate=$os.InstallDate; lastBoot=$os.LastBootUpTime; psVersion="$($PSVersionTable.PSVersion)"; dotnet="" }
try { $hw.system.dotnet = (Get-ChildItem "HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full" -EA SilentlyContinue | Get-ItemProperty -Name Release -EA SilentlyContinue).Release } catch {}

# 内存条
$mem = @(wmi Win32_PhysicalMemory | %{ @{ capacity=([math]::Round($_.Capacity/1GB,0)); speed=$_.Speed; manufacturer=$_.Manufacturer; partNumber=$_.PartNumber; slot=$_.DeviceLocator; type=$_.MemoryType; formFactor=$_.FormFactor } })
$hw.memory = $mem

# 硬盘
$disks = @()
$pd = wmi Win32_DiskDrive | %{ 
    $d = @{ model=$_.Model; size=([math]::Round($_.Size/1GB,0)); interface=$_.InterfaceType; media=$_.MediaType; serial=$_.SerialNumber; partitions=@() }
    wmi Win32_DiskDriveToDiskPartition | ?{$_.Antecedent -match $_.DeviceID -and $_.Dependent} | %{
        $pn = $_.Dependent.Split('"')[1]; $part = wmi Win32_LogicalDisk | ?{$_.DeviceID -and (wmi Win32_LogicalDiskToPartition | ?{$_.Antecedent -match $pn}).Dependent -match $_.DeviceID} | Select -First 1
        if($part){ $d.partitions += @{ drive=$part.DeviceID; size=([math]::Round($part.Size/1GB,1)); free=([math]::Round($part.FreeSpace/1GB,1)); fs=$part.FileSystem } }
    }
    $disks += $d
}
$hw.disks = $disks

# GPU
$gpus = @(wmi Win32_VideoController | %{ @{ name=$_.Name; driver=$_.DriverVersion; ram=([math]::Round($_.AdapterRAM/1MB,0)); resolution="$($_.CurrentHorizontalResolution)x$($_.CurrentVerticalResolution)"; refresh=$_.CurrentRefreshRate } })
$hw.gpu = $gpus

# 网卡
$nics = @()
try { $nicData = if(Get-Command Get-NetAdapter -EA SilentlyContinue){Get-NetAdapter -Physical -EA SilentlyContinue|%{@{name=$_.Name; mac=$_.MacAddress; speed=$_.LinkSpeed; status=$_.Status}}}else{wmi Win32_NetworkAdapter|?{$_.PhysicalAdapter -and $_.NetEnabled}|%{@{name=$_.Name; mac=$_.MACAddress; speed=$_.Speed; status=$(if($_.NetConnectionStatus -eq 2){'Up'}else{'Down'})}}}; $nics += $nicData } catch{}
foreach($n in $nics){ try{ $ip = wmi Win32_NetworkAdapterConfiguration | ?{$_.MACAddress -eq $n.mac} | Select -First 1; $n.ip = $ip.IPAddress[0]; $n.gateway = $ip.DefaultIPGateway[0]; $n.dns = $ip.DNSServerSearchOrder -join ',' }catch{} }
$hw.network = $nics

# 显示器
$mons = @(wmi WmiMonitorID | %{ $n='';$s=''; foreach($c in $_.ManufacturerName){if($c){$n+=[char]$c}}; foreach($c in $_.SerialNumberID){if($c){$s+=[char]$c}}; @{name=$n; serial=$s; mfgWeek=$_.WeekOfManufacture; mfgYear=$_.YearOfManufacture} })
$hw.monitors = $mons

# 电源（笔记本电池）
try { $bat = wmi Win32_Battery | Select -First 1; $hw.battery = @{ name=$bat.Name; chemistry=$bat.Chemistry; designCapacity=$bat.DesignCapacity; fullCapacity=$bat.FullChargeCapacity; status=$bat.Status; health=$(if($bat.DesignCapacity -gt 0){[math]::Round($bat.FullChargeCapacity/$bat.DesignCapacity*100,1)}else{0}) } } catch{ $hw.battery=$null }

# 输入设备
$input = @()
try { wmi Win32_Keyboard | %{ $input += @{ type='keyboard'; name=$_.Name; layout=$_.Layout } } } catch{}
try { wmi Win32_PointingDevice | %{ $input += @{ type='mouse'; name=$_.Name; buttons=$_.NumberOfButtons } } } catch{}
$hw.inputDevices = $input

# 已安装软件列表
$sw = @()
try {
  Get-ChildItem "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall" -EA SilentlyContinue | %{
    $n = (Get-ItemProperty $_.PSPath -Name DisplayName -EA SilentlyContinue).DisplayName
    $v = (Get-ItemProperty $_.PSPath -Name DisplayVersion -EA SilentlyContinue).DisplayVersion
    $p = (Get-ItemProperty $_.PSPath -Name Publisher -EA SilentlyContinue).Publisher
    if($n){ $sw += @{name=$n;version=$v;publisher=$p} }
  }
} catch{}
$hw.software = $sw | Sort-Object name

if($Json){$hw|ConvertTo-Json -Compress -Depth 5; exit}
if($Quiet){exit}

Write-Host "`n═══════════════════════════════════════════════════" -F Cyan
Write-Host "  金网通 V2 · 硬件扫描报告" -F Cyan
Write-Host "═══════════════════════════════════════════════════`n" -F Cyan
Write-Host " 系统: $($hw.system.model) | $($hw.system.osName) | $(if($hw.battery){'笔记本'}else{'台式机'})" -F White
Write-Host " CPU : $($hw.cpu.name) ($($hw.cpu.cores)C/$($hw.cpu.threads)T @ $($hw.cpu.maxSpeed)MHz)" -F Gray
Write-Host " 内存: $(($hw.memory|Measure-Object capacity -Sum).Sum/1)GB ($($hw.memory.Count) 槽)" -F Gray
Write-Host " 主板: $($hw.motherboard.manufacturer) $($hw.motherboard.product)" -F Gray
Write-Host " 磁盘: $(($hw.disks|%{$_.size}|Measure-Object -Sum).Sum)GB 总计 | $($hw.disks.Count) 块" -F Gray
Write-Host " 显卡: $($hw.gpu[0].name)" -F Gray
Write-Host " 网卡: $($hw.network.Count) 个 | IP $(($hw.network|?{$_.ip})[0].ip)" -F Gray
if($hw.battery){ Write-Host " 电池: 健康度 $($hw.battery.health)%" -F $(if($hw.battery.health -lt 70){'Red'}else{'Gray'}) }
Write-Host " BIOS: $($hw.bios.vendor) $($hw.bios.version)" -F Gray
Write-Host " 软件: $($hw.software.Count) 款已安装`n" -F Gray
# 简要性能评估
$score = 0; if($hw.cpu.cores -ge 8){$score+=3}elseif($hw.cpu.cores -ge 4){$score+=2}else{$score+=1}
$totalRam = ($hw.memory|Measure-Object capacity -Sum).Sum/1
if($totalRam -ge 32){$score+=3}elseif($totalRam -ge 16){$score+=2}elseif($totalRam -ge 8){$score+=1}
if($hw.gpu[0].ram -gt 4000){$score+=2}elseif($hw.gpu[0].ram -gt 1000){$score+=1}
$isSSD = ($hw.disks|%{if($_.model -match 'SSD|NVMe|M\.2'){1}}|Measure-Object -Sum).Sum
if($isSSD -gt 0){$score+=2}
$rating=switch($score){{$_ -ge 8}{'⭐⭐⭐⭐⭐ 高性能'}{$_ -ge 5}{'⭐⭐⭐⭐ 中高端'}{$_ -ge 3}{'⭐⭐⭐ 日常够用'}{default{'⭐⭐ 基础配置'}}}
Write-Host " ┌─────────────────────────────────────────┐"
Write-Host " │ 性能评估：$rating".PadRight(44)+"│" -F Yellow
if($totalRam -lt 8){ Write-Host " │ 💡 建议：内存 < 8GB，可考虑升级          │" -F Yellow }
if(-not $isSSD){ Write-Host " │ 💡 建议：机械硬盘，升级 SSD 体验明显提升   │" -F Yellow }
Write-Host " └─────────────────────────────────────────┘`n" -F Yellow
Write-Host "═══════════════════════════════════════════════════`n" -F Cyan