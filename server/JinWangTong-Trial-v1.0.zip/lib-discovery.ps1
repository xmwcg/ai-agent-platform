<#
.SYNOPSIS  局域网发现库：子网枚举、端口探测、对端发现
.DESCRIPTION  V2 兼容层：PS 2.0+ 安全。所有 .NET 构造函数替换为 New-Object。
              DNS 查询使用 GetHostEntry 替代已过时的 GetHostByAddress。
#>

function Get-SubnetHosts {
    param(
        [string]$IP,
        [int]$Prefix
    )
    # V2 兼容：[Net.IPAddress]::new($b) → New-Object
    $ipObj = [Net.IPAddress]::Parse($IP)
    $ipBytes = $ipObj.GetAddressBytes()
    if ([BitConverter]::IsLittleEndian) { [array]::Reverse($ipBytes) }
    $ipInt   = [BitConverter]::ToUInt32($ipBytes, 0)
    $maskInt = if ($Prefix -eq 0) { [uint32]0 } else { ([uint32]0xFFFFFFFF) -shl (32 - $Prefix) }
    $netInt  = $ipInt -band $maskInt
    $bcast   = $netInt -bor ((-bnot $maskInt) -band [uint32]0xFFFFFFFF)
    $hosts = @()
    for ($i = $netInt + 1; $i -lt $bcast; $i++) {
        $b = [BitConverter]::GetBytes($i)
        if ([BitConverter]::IsLittleEndian) { [array]::Reverse($b) }
        $hosts += (New-Object Net.IPAddress -ArgumentList @(,$b)).ToString()
    }
    $hosts
}

function Test-TcpPort {
    param([string]$IP, [int]$Port, [int]$TimeoutMs = 300)
    $tcp = New-Object System.Net.Sockets.TcpClient
    try {
        $iar = $tcp.BeginConnect($IP, $Port, $null, $null)
        if ($iar.AsyncWaitHandle.WaitOne($TimeoutMs)) { $tcp.EndConnect($iar); $true }
        else { $false }
    } catch { $false }
    finally { try { $tcp.Close() } catch {} }
}

function Get-LocalSubnet {
    # V2 兼容：Get-NetIPAddress(PS 4.0+) → 降级 WMI
    $addr = $null
    try {
        $addr = Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue |
            Where-Object { $_.InterfaceAlias -notmatch 'Loopback' -and $_.PrefixLength -ge 8 -and $_.PrefixLength -le 30 } |
            Sort-Object -Property PrefixLength -Descending |
            Select-Object -First 1
    } catch { }
    if (-not $addr) {
        # 降级到 WMI（PS 2.0 可用）
        try {
            $nics = Get-WmiObject Win32_NetworkAdapterConfiguration -Filter "IPEnabled=TRUE" -ErrorAction SilentlyContinue
            foreach ($nic in $nics) {
                if ($nic.IPAddress -and $nic.IPSubnet) {
                    for ($j = 0; $j -lt $nic.IPAddress.Count; $j++) {
                        $ipStr = $nic.IPAddress[$j]
                        if ($ipStr -match '^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$' -and $ipStr -ne '127.0.0.1') {
                            $mask = $nic.IPSubnet[$j]
                            $maskParts = $mask.Split('.')
                            $maskBin = ([int]$maskParts[0] -shl 24) -bor ([int]$maskParts[1] -shl 16) -bor ([int]$maskParts[2] -shl 8) -bor [int]$maskParts[3]
                            $prefix = 0
                            while ($maskBin -band 0x80000000) { $prefix++; $maskBin = $maskBin -shl 1 }
                            return [PSCustomObject]@{ IP = $ipStr; Prefix = $prefix }
                        }
                    }
                }
            }
        } catch { }
    }
    if (-not $addr) { return $null }
    [PSCustomObject]@{ IP = $addr.IPAddress; Prefix = $addr.PrefixLength }
}

function Find-Peers {
    param(
        [string]$Range = "auto",
        [string]$SelfIP,
        [int]$MaxHosts = 1024
    )
    if ($Range -eq "auto") {
        $sub = Get-LocalSubnet
        if (-not $sub) { Write-Warning "无法确定本机子网。"; return @() }
        $hosts = Get-SubnetHosts -IP $sub.IP -Prefix $sub.Prefix
    } elseif ($Range -match '^(.+?)\.(\d+)-(\d+)$') {
        $base = $Matches[1]; $a = [int]$Matches[2]; $b = [int]$Matches[3]
        $hosts = @(); for ($i = $a; $i -le $b; $i++) { $hosts += "$base.$i" }
    } elseif ($Range -match '^(.+?)/(\d+)$') {
        $hosts = Get-SubnetHosts -IP $Matches[1] -Prefix ([int]$Matches[2])
    } else { Write-Warning "Range 格式无法识别：$Range"; return @() }

    if ($hosts.Count -gt $MaxHosts) {
        Write-Warning "主机数 $($hosts.Count) 超过上限 $MaxHosts，截断。"
        $hosts = $hosts | Select-Object -First $MaxHosts
    }

    $peers = @()
    Write-Host "扫描 $($hosts.Count) 个地址..." -ForegroundColor Cyan
    foreach ($ip in $hosts) {
        $alive = $false
        if ($ip -eq $SelfIP) { $alive = $true }
        else {
            if (Test-Connection -ComputerName $ip -Count 1 -TimeoutSeconds 1 -Quiet -ErrorAction SilentlyContinue) { $alive = $true }
            elseif (Test-TcpPort -IP $ip -Port 445) { $alive = $true }
            elseif (Test-TcpPort -IP $ip -Port 3389) { $alive = $true }
        }
        if ($alive) {
            $name = $ip
            # V2 兼容：GetHostEntry 替代已过时的 GetHostByAddress
            try {
                try { $name = [Net.Dns]::GetHostEntry($ip).HostName } catch { $name = $ip }
            } catch {}
            $rdp = Test-TcpPort -IP $ip -Port 3389 -TimeoutMs 200
            $smb = Test-TcpPort -IP $ip -Port 445  -TimeoutMs 200
            $peers += [PSCustomObject]@{
                IP     = $ip
                Name   = $name
                RDP    = $rdp
                SMB    = $smb
                IsSelf = ($ip -eq $SelfIP)
            }
        }
    }
    $peers
}