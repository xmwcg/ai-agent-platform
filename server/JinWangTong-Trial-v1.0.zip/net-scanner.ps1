<#
.SYNOPSIS  金网通 V2 · 网络扫描引擎
.DESCRIPTION  PS 2.0+ 兼容。内外网IP/路由/带宽估算/端口监听/DNS/代理/防火墙
#>
param([switch]$Json,[switch]$Quiet)
$r=@{}

# 内网IP
$r.interfaces=@()
try{ if(Get-Command Get-NetIPAddress -EA SilentlyContinue){ Get-NetIPAddress -AddressFamily IPv4 -EA SilentlyContinue|?{$_.InterfaceAlias -notmatch 'Loopback'}|%{ $a=$_; $r.interfaces+=@{name=$a.InterfaceAlias;ip=$a.IPAddress;mask=$a.PrefixLength;index=$a.InterfaceIndex} } } }catch{}
if(-not $r.interfaces){
  try{ wmi Win32_NetworkAdapterConfiguration|?{$_.IPEnabled}|%{ $r.interfaces+=@{name=$_.Description;ip=$_.IPAddress[0];mask=$_.IPSubnet[0];gateway=$_.DefaultIPGateway[0];dns=($_.DNSServerSearchOrder-join',');dhcp=$_.DHCPEnabled;mac=$_.MACAddress} } }catch{}
}

# 外网IP（尝试多个API）
$r.externalIP=''
try{ $wc=New-Object Net.WebClient; $wc.Headers.Add('User-Agent','curl'); $r.externalIP=($wc.DownloadString('http://ipinfo.io/ip') -replace '\s','') }catch{}
if(-not $r.externalIP){ try{ $r.externalIP=(New-Object Net.WebClient).DownloadString('http://ifconfig.me/ip') -replace '\s','' }catch{} }

# 路由表
$r.routes=@()
try{ wmi Win32_IP4RouteTable|?{$_.Destination -ne '127.0.0.1'}|Select -First 10|%{ $r.routes+=@{dest=$_.Destination;mask=$_.Mask;nexthop=$_.NextHop;interface=$_.InterfaceIndex;metric=$_.Metric1} }}catch{}

# 端口监听
$r.listeners=@()
try{ Get-NetTCPConnection -State Listen -EA SilentlyContinue|Select -First 20|%{ $r.listeners+=@{port=$_.LocalPort;process=$_.OwningProcess} } }catch{
  try{ netstat -an 2>$null|?{$_ -match 'LISTENING'}|Select -First 20|%{ $m=$_ -replace '\s+',' ' -split ' '; $r.listeners+=@{port=$m[1].Split(':')[-1];addr=$m[1]} } }catch{}
}

# DNS
$r.dns=@()
try{ Get-DnsClientServerAddress -EA SilentlyContinue -AddressFamily IPv4|?{$_.ServerAddresses}|%{ $r.dns+=@{interface=$_.InterfaceAlias;servers=($_.ServerAddresses-join',')} } }catch{}

# 带宽估算（简单：下载一个小文件的耗时）
$r.bandwidth=0
try{ $sw=[Diagnostics.Stopwatch]::StartNew(); (New-Object Net.WebClient).DownloadString('http://httpbin.org/bytes/102400')>$null; $sw.Stop(); $r.bandwidth=[math]::Round(100/$sw.Elapsed.TotalSeconds,0) }catch{}

# 代理设置
$r.proxy=@{ enabled=$false }
try{ $pk='HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings'; $r.proxy.enabled=(Get-ItemProperty $pk -EA SilentlyContinue).ProxyEnable -eq 1; if($r.proxy.enabled){ $r.proxy.server=(Get-ItemProperty $pk -EA SilentlyContinue).ProxyServer } }catch{}

# 防火墙
$r.firewall=@{ enabled=$false; profiles=@() }
try{ if(Get-Command Get-NetFirewallProfile -EA SilentlyContinue){ Get-NetFirewallProfile|%{ $r.firewall.profiles+=@{name=$_.Name;enabled=$_.Enabled} } }else{ $r.firewall.profiles+=@{name='未知';enabled='无法检测'} } }catch{}

if($Json){$r|ConvertTo-Json -Compress -Depth 4;exit}
if($Quiet){exit}
Write-Host "`n══ 网络环境扫描 ══`n" -F Cyan
foreach($i in $r.interfaces){ Write-Host " 网卡: $($i.name) → $($i.ip)/$($i.mask)" -F White }
if($r.externalIP){ Write-Host " 外网IP: $($r.externalIP)" -F White }
Write-Host " DNS: $(if($r.dns){($r.dns[0].servers)}else{'未知'})" -F Gray
Write-Host " 代理: $(if($r.proxy.enabled){$r.proxy.server}else{'未设置'})" -F Gray
Write-Host " 防火墙: $(($r.firewall.profiles|%{$_.name+':'+$_.enabled})-join' | ')" -F Gray
Write-Host " 带宽: ~$($r.bandwidth) KB/s" -F Gray
Write-Host " 监听端口: $(($r.listeners|Measure-Object).Count) 个" -F Gray
($r.listeners|Select -First 10|%{ Write-Host "   :$($_.port)" -F Gray })
Write-Host ""
function wmi($c){try{if(Get-Command Get-CimInstance -EA SilentlyContinue){Get-CimInstance $c -EA Stop}else{Get-WmiObject $c -EA Stop}}catch{}}