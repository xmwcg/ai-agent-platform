<#
.SYNOPSIS  金网通 V2 · 操作系统与软件环境扫描
.DESCRIPTION  PS 2.0+ 兼容。扫描 OS/用户/服务/环境变量/启动项/进程
#>
param([switch]$Json,[switch]$Quiet)
$r=@{}

# OS
$os=wmi Win32_OperatingSystem|Select -First 1
$r.os=@{caption=$os.Caption;version=$os.Version;build=$os.BuildNumber;arch=$os.OSArchitecture;installDate=$os.InstallDate;lastBoot=$os.LastBootUpTime;locale=(Get-Culture).Name;timezone=([TimeZoneInfo]::Local).DisplayName}

# 用户
$r.users=@(wmi Win32_UserAccount|?{$_.Disabled -eq $false}|%{@{name=$_.Name;fullName=$_.FullName;domain=$_.Domain;localAccount=$_.LocalAccount}})

# 环境变量
$r.env=@{ PATH=$env:PATH; TEMP=$env:TEMP; USERPROFILE=$env:USERPROFILE; COMPUTERNAME=$env:COMPUTERNAME; USERNAME=$env:USERNAME; PROCESSOR_ARCHITECTURE=$env:PROCESSOR_ARCHITECTURE }

# PS 版本
$r.powershell=@{ version="$($PSVersionTable.PSVersion)"; edition=$PSVersionTable.PSEdition; clrVersion=$PSVersionTable.CLRVersion; modules=(Get-Module -ListAvailable|Measure-Object).Count }

# 服务（关键服务状态）
$svcs=@("WinRM","LanmanServer","LanmanWorkstation","W32Time","wuauserv","BITS","Spooler","Dnscache")
$r.services=@()
foreach($sn in $svcs){ try{ $s=Get-Service $sn -EA SilentlyContinue; $r.services+=@{name=$sn;status=$s.Status;startType=$s.StartType} }catch{$r.services+=@{name=$sn;status='unknown'} } }

# 启动项
$r.startup=@()
try{ Get-ChildItem "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" -EA SilentlyContinue|%{ $v=(Get-ItemProperty $_.PSPath -EA SilentlyContinue); foreach($pv in $v.PSObject.Properties){ if($pv.Name -notmatch '^PS'){$r.startup+=@{name=$pv.Name;path=$pv.Value;source='HKLM'} }}} }catch{}
try{ Get-ChildItem "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" -EA SilentlyContinue|%{ $v=(Get-ItemProperty $_.PSPath -EA SilentlyContinue); foreach($pv in $v.PSObject.Properties){ if($pv.Name -notmatch '^PS'){$r.startup+=@{name=$pv.Name;path=$pv.Value;source='HKCU'} }}} }catch{}

# 进程 Top 10 内存
$r.topProcs=@(Get-Process|Sort-Object WorkingSet64 -Descending|Select -First 10|%{@{name=$_.ProcessName; pid=$_.Id; memoryMB=[math]::Round($_.WorkingSet64/1MB,1); cpuTime=$_.TotalProcessorTime.ToString()} })

if($Json){$r|ConvertTo-Json -Compress -Depth 4;exit}
if($Quiet){exit}
Write-Host "`n══ 操作系统与软件环境 ══`n" -F Cyan
Write-Host " OS: $($r.os.caption) ($($r.os.arch))" -F White
Write-Host " 版本: $($r.os.version) / 构建: $($r.os.build)" -F Gray
Write-Host " 安装: $($r.os.installDate) / 启动: $($r.os.lastBoot)" -F Gray
Write-Host " PS : $($r.powershell.version) ($($r.powershell.edition)) / $($r.powershell.modules) 模块" -F Gray
Write-Host " 用户: $(($r.users|Measure-Object).Count) 个本地账户" -F Gray
Write-Host "`n 关键服务:" -F Yellow
foreach($s in $r.services){ $c=if($s.status-eq'Running'){'Green'}else{'Red'}; Write-Host "   $($s.name.PadRight(20)) $($s.status.PadRight(10)) $($s.startType)" -F $c }
Write-Host "`n 启动项: $(($r.startup|Measure-Object).Count) 个" -F Gray
Write-Host " 内存 Top 进程:" -F Yellow
$r.topProcs|%{ Write-Host "   $($_.name.PadRight(20)) $($_.memoryMB.ToString().PadLeft(8)) MB  PID:$($_.pid)" -F Gray }
Write-Host ""
function wmi($c){try{if(Get-Command Get-CimInstance -EA SilentlyContinue){Get-CimInstance $c -EA Stop}else{Get-WmiObject $c -EA Stop}}catch{}}
function Get-Culture { try { [System.Globalization.CultureInfo]::CurrentCulture } catch { New-Object System.Globalization.CultureInfo "zh-CN" } }