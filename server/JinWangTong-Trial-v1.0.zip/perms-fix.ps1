<#
.SYNOPSIS
    金网通计算机管理系统 V2 · 权限检测与自动修复工具
.DESCRIPTION
    检测当前用户权限状态，提供一键提权或修复方案。
    兼容 PowerShell 2.0+。
    - 如果不是管理员：提供界面引导的提权方案
    - 如果管理员权限不足（如组策略限制）：给出修复步骤
    - 检测 WinRM/SMB/防火墙等关键服务权限
#>

param(
    [switch]$Fix,        # 自动修复模式
    [switch]$Json,       # JSON输出
    [switch]$Quiet       # 静默模式
)

$PermReport = @{
    isAdmin            = $false
    isElevated         = $false
    canEnableWinRM     = $false
    canConfigureFirewall = $false
    canCreateShares    = $false
    canManageUsers     = $false
    uacEnabled         = $false
    fixCommands        = @()
    issues             = @()
}

# ---------- 1. 管理员权限 ----------
try {
    $wp = [Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
    $PermReport.isAdmin = $wp.IsInRole([Security.Principal.WindowsBuiltinRole]::Administrator)
} catch { $PermReport.isAdmin = $false }

# 检查是否是提权的（UAC已通过）
$PermReport.isElevated = $PermReport.isAdmin

# ---------- 2. UAC状态 ----------
try {
    $uacKey = Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -Name "EnableLUA" -ErrorAction SilentlyContinue
    $PermReport.uacEnabled = ($uacKey.EnableLUA -ne 0)
} catch { $PermReport.uacEnabled = $true }

# ---------- 3. 各权限能力检测 ----------
$PermReport.canEnableWinRM = $PermReport.isAdmin
$PermReport.canConfigureFirewall = $PermReport.isAdmin
$PermReport.canCreateShares = $PermReport.isAdmin
$PermReport.canManageUsers = $PermReport.isAdmin

# ---------- 4. 修复命令 ----------
if (-not $PermReport.isAdmin) {
    $PermReport.fixCommands += @{
        title   = "以管理员身份运行 PowerShell"
        method  = "manual"
        steps   = @(
            "1. 按 Win+R 键，输入 powershell",
            "2. 右键 PowerShell 图标 → 选择「以管理员身份运行」",
            "3. 在打开的窗口中重新运行本脚本"
        )
        command = "Start-Process powershell -Verb RunAs"
    }
}

if ($PermReport.isAdmin) {
    # 管理员可用的修复
    if (-not (Get-Service -Name "WinRM" -ErrorAction SilentlyContinue | Where-Object {$_.Status -eq 'Running'})) {
        $PermReport.fixCommands += @{
            title   = "启用 WinRM 远程管理"
            method  = "command"
            command = "Enable-PSRemoting -Force; Set-Service WinRM -StartupType Automatic; Start-Service WinRM"
        }
    }
    if (-not (Get-Service -Name "LanmanServer" -ErrorAction SilentlyContinue | Where-Object {$_.Status -eq 'Running'})) {
        $PermReport.fixCommands += @{
            title   = "启用文件共享 (SMB)"
            method  = "command"
            command = "Set-Service LanmanServer -StartupType Automatic; Start-Service LanmanServer"
        }
    }
    # 防火墙：启用文件和打印机共享规则
    try {
        $rules = netsh advfirewall firewall show rule name="文件和打印机共享(回显请求 - ICMPv4-In)" 2>&1
        if ($rules -notmatch "允许") {
            $PermReport.fixCommands += @{
                title   = "启用文件和打印机共享防火墙规则"
                method  = "command"
                command = 'netsh advfirewall firewall set rule group="文件和打印机共享" new enable=Yes'
            }
        }
    } catch { }
}

# ---------- 5. Net user降级可用性 ----------
try {
    $null = cmd /c "net user 2>nul"
    $PermReport.fixCommands += @{
        title   = "用户管理方式"
        method  = "info"
        command = "net user 和 net localgroup 命令可用（无需 PowerShell 5.1+）"
    }
} catch { }

# ---------- 输出 ----------
if ($Json) {
    $PermReport | ConvertTo-Json -Compress
    exit
}

if ($Quiet) { exit 0 }

Write-Host ""
Write-Host "════════════════════════════════════════════════════════" -ForegroundColor Magenta
Write-Host "  金网通 V2 · 权限检测与修复工具" -ForegroundColor Magenta
Write-Host "════════════════════════════════════════════════════════" -ForegroundColor Magenta
Write-Host ""

# 状态显示
$statusColor = if ($PermReport.isAdmin) { "Green" } else { "Yellow" }
$statusText = if ($PermReport.isAdmin) { "✅ 已获取管理员权限" } else { "⚠️ 当前未以管理员身份运行" }
Write-Host "  状态：$statusText" -ForegroundColor $statusColor

Write-Host "  可用能力："
Write-Host "    远程管理(WinRM): $(if($PermReport.canEnableWinRM){'✅'}else{'❌'})"
Write-Host "    防火墙配置:      $(if($PermReport.canConfigureFirewall){'✅'}else{'❌'})"
Write-Host "    文件共享(SMB):   $(if($PermReport.canCreateShares){'✅'}else{'❌'})"
Write-Host "    用户管理:        $(if($PermReport.canManageUsers){'✅'}else{'❌'})"
Write-Host "    UAC:             $(if($PermReport.uacEnabled){'已启用'}else{'已禁用'})"

Write-Host ""

if ($PermReport.fixCommands.Count -gt 0) {
    Write-Host "  ── 修复方案 ──" -ForegroundColor Cyan
    Write-Host ""
    foreach ($fix in $PermReport.fixCommands) {
        Write-Host "  📋 $($fix.title)" -ForegroundColor White
        if ($fix.method -eq "manual") {
            # 手动步骤 → 显示步骤
            foreach ($step in $fix.steps) {
                Write-Host "     $step"
            }
        } elseif ($fix.method -eq "command") {
            Write-Host "     ┌─────────────────────────────────────────────────┐"
            Write-Host "     │ $(if($fix.command.Length -gt 55){$fix.command.Substring(0,52)+'...'}else{$fix.command})"
            Write-Host "     └─────────────────────────────────────────────────┘" -ForegroundColor DarkGray
            Write-Host "     以管理员身份运行以上命令即可修复。"
        } else {
            Write-Host "     $($fix.command)"
        }
        Write-Host ""
    }

    # 一键修复
    if ($Fix -and $PermReport.isAdmin) {
        Write-Host "  🔧 自动修复中..." -ForegroundColor Yellow
        foreach ($fix in $PermReport.fixCommands) {
            if ($fix.method -eq "command") {
                Write-Host "    执行: $($fix.title)..."
                try {
                    Invoke-Expression $fix.command 2>$null
                    Write-Host "    ✅ 完成" -ForegroundColor Green
                } catch {
                    Write-Host "    ❌ 失败: $_" -ForegroundColor Red
                }
            }
        }
        Write-Host ""
        Write-Host "  修复完成。请重新运行 compat-check.ps1 验证。" -ForegroundColor Green
    }
}

Write-Host "════════════════════════════════════════════════════════" -ForegroundColor Magenta