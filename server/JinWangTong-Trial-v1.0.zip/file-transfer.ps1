<#
.SYNOPSIS  金网通 V2 · 局域网文件传输工具
.DESCRIPTION  PS 2.0+ 兼容。启动临时HTTP服务供局域网内其他机器下载文件。
  也支持接收模式（创建共享上传目录）。
#>
param([string]$Dir, [int]$Port=9876, [switch]$Receive)

if(-not $Dir){ $Dir = if($Receive){ Join-Path $env:USERPROFILE "金网通-共享文件夹" } else { Get-Location } }

if($Receive){
  # 创建共享文件夹用于接收文件
  if(-not (Test-Path $Dir)){ New-Item -ItemType Directory -Path $Dir -Force >$null }
  Write-Host "`n══ 局域网文件接收 ══`n" -F Cyan
  Write-Host " 共享文件夹: $Dir" -F White

  try{
    # 尝试共享为 JinWangTong-Share
    $shareName = "JinWangTong-Share"
    net share $shareName /delete >$null 2>&1
    net share $shareName=$Dir /grant:Everyone,FULL >$null 2>&1
    Write-Host " ✓ 已共享为: \\$env:COMPUTERNAME\$shareName" -F Green
    Write-Host " 局域网内其他电脑在文件管理器地址栏输入:" -F Gray
    Write-Host "   \\$env:COMPUTERNAME\$shareName" -F White
    Write-Host " 即可上传文件到此目录。" -F Gray
    Write-Host ""
    Write-Host " 关闭共享: net share $shareName /delete" -F Gray
  }catch{
    Write-Warning "SMB共享创建失败。尝试其他方式..."
    # 降级为 HTTP 上传
    Write-Host " 请使用: .\file-transfer.ps1 -Dir `"$Dir`"  启动HTTP服务" -F Yellow
  }
  return
}

# HTTP 文件服务器（发送模式）
if(-not (Test-Path $Dir)){ Write-Warning "目录不存在: $Dir"; return }

Write-Host "`n══ 局域网文件传输 ══`n" -F Cyan
Write-Host " 目录: $Dir" -F White

# 获取本机IP
$ip=''
try{if(Get-Command Get-NetIPAddress -EA SilentlyContinue){ $ip=(Get-NetIPAddress -AddressFamily IPv4|?{$_.InterfaceAlias -notmatch 'Loopback'}|Select -First 1).IPAddress } }catch{
  try{ $ip=(Get-WmiObject Win32_NetworkAdapterConfiguration|?{$_.IPEnabled}|Select -First 1).IPAddress[0] }catch{}
}

Write-Host " 地址: http://$($ip):$Port" -F Yellow
Write-Host " 局域网内其他电脑浏览器输入以上地址即可浏览和下载文件。" -F Gray
Write-Host ""
Write-Host " 按 Ctrl+C 停止服务。" -F Gray
Write-Host ""

# 使用 .NET HttpListener 建简易HTTP服务器（PS 2.0+ 兼容）
$listener = $null
try {
  $listener = New-Object System.Net.HttpListener
  $listener.Prefixes.Add("http://+:$Port/")
  $listener.Start()
  Write-Host " 服务已启动。等待连接..." -F Green

  # 简单循环（Ctrl+C 停止）
  while($listener.IsListening){
    try{
      $ctx = $listener.GetContext()
      $req = $ctx.Request
      $res = $ctx.Response
      $filePath = [System.Uri]::UnescapeDataString($req.Url.LocalPath.TrimStart('/'))
      if(-not $filePath){ $filePath = "index.html" }
      $fullPath = Join-Path $Dir $filePath

      # 安全检查：不允许../跳出目录
      $fullPath = [System.IO.Path]::GetFullPath($fullPath)
      if(-not $fullPath.StartsWith((Get-Item $Dir).FullName, [StringComparison]::OrdinalIgnoreCase)){
        $res.StatusCode=403
        $buf=[Text.Encoding]::UTF8.GetBytes('禁止访问')
        $res.OutputStream.Write($buf,0,$buf.Length)
        $res.Close(); continue
      }

      if(Test-Path $fullPath -PathType Container){
        # 目录→简单HTML列表
        $items=Get-ChildItem $fullPath|%{
          $name=$_.Name; $sz=if($_.PSIsContainer){'[目录]'}else{'{0:N1} KB' -f ($_.Length/1KB)}; $href=$filePath+'/'+$name
          "<tr><td><a href='$href'>$name</a></td><td>$sz</td><td>$($_.LastWriteTime.ToString('yyyy-MM-dd HH:mm'))</td></tr>"
        }
        $html="<html><head><meta charset='utf-8'><title>金网通·局域网文件共享</title><style>body{font-family:Microsoft YaHei,sans-serif;background:#0a0e17;color:#e6e9ef;padding:30px}a{color:#FF5C1A}h2{color:#fff}table{width:100%;border-collapse:collapse}td{padding:10px 14px;border-bottom:1px solid #1e2d45}td:first-child{font-size:15px}</style></head><body><h2>📁 $filePath</h2><table>$($items -join "`n")</table><hr><p style='color:#555'>金网通 V2 · 局域网文件传输</p></body></html>"
        $buf=[Text.Encoding]::UTF8.GetBytes($html)
        $res.ContentType='text/html; charset=utf-8'
      }elseif(Test-Path $fullPath){
        $buf=[IO.File]::ReadAllBytes($fullPath)
        $ext=[IO.Path]::GetExtension($fullPath).ToLower()
        $mime=switch($ext){{'.zip'}{'application/zip'}{'.pdf'}{'application/pdf'}{'.jpg'}{'image/jpeg'}{'.png'}{'image/png'}{'.mp4'}{'video/mp4'}{'.txt'}{'text/plain; charset=utf-8'}{'.docx'}{'application/vnd.openxmlformats-officedocument.wordprocessingml.document'}default{'application/octet-stream'}}
        $res.ContentType=$mime
        $res.AddHeader('Content-Disposition',"attachment; filename=`"$(Split-Path $fullPath -Leaf)`"")
      }else{
        $res.StatusCode=404
        $buf=[Text.Encoding]::UTF8.GetBytes('文件未找到')
      }
      $res.ContentLength64=$buf.Length
      $res.OutputStream.Write($buf,0,$buf.Length)
      $res.Close()
    }catch{ if($listener.IsListening){ Write-Warning "连接处理错误: $_" } }
  }
}catch{
  Write-Error "HTTP服务启动失败: $_"
  Write-Host "提示: 可能需要管理员权限，或端口 $Port 已被占用。" -F Yellow
  Write-Host "试试换个端口: .\file-transfer.ps1 -Port 9999" -F Gray
}finally{
  try{ if($listener){ $listener.Stop(); $listener.Close() } }catch{}
}