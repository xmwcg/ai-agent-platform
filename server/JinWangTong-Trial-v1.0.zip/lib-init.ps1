<#
.SYNOPSIS  统一初始化：编码 + 控制台 + 自动提权（所有入口脚本请先 dot-source 本文件）
.DESCRIPTION
  · 统一文件写入编码为 UTF-8（带 BOM），彻底杜绝 PowerShell 5.1 默认 ANSI 读取导致的中文乱码；
    PowerShell 7 下使用 utf8BOM，保证跨版本一致。
  · 控制台输出设为 UTF-8，避免中文在终端显示乱码。
  · 提供 Request-AdminOrElevate：非管理员时自动提权（UAC 由用户确认），实现"权限最大化 + 用户决策"。
  · V2 兼容层：PS 2.0+ 安全，自动检测并使用兼容语法。
#>

# ---------- 1) 文件写入一律 UTF-8（带 BOM，跨 PS 5.1 / 7 一致） ----------
# V2 兼容：System.Management.Automation.PSVersionHashTable 仅在 PS 2.0+ 可用（PS 2.0 返回 2.0）
try { $psVer = $PSVersionTable.PSVersion.Major } catch { $psVer = 2 }
if ($psVer -ge 7) {
    $script:Enc = 'utf8BOM'
} elseif ($psVer -ge 5) {
    $script:Enc = 'utf8'   # Windows PowerShell 5.1 中 utf8 = 带 BOM 的 UTF-8
} else {
    $script:Enc = 'UTF8'   # PS 2.0-4.0 使用 UTF8（无 BOM，但内容正确）
}
try {
    $PSDefaultParameterValues = @{}
    $PSDefaultParameterValues['Out-File:Encoding']      = $script:Enc
    $PSDefaultParameterValues['Set-Content:Encoding']   = $script:Enc
    $PSDefaultParameterValues['Add-Content:Encoding']   = $script:Enc
    $PSDefaultParameterValues['Export-Csv:Encoding']    = $script:Enc
} catch {
    # PS 2.0 不支持 System.Management.Automation.DefaultParameterDictionary，跳过（需在 Out-File 时手动指定 -Encoding）
    Write-Debug "编码预设不可用，将在写入时手动指定"
}

# ---------- 2) 控制台输出 UTF-8，避免中文在终端乱码 ----------
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch { }

# ---------- 3) 自动提权（权限最大化，UAC 由用户确认 = 用户决策） ----------
function Request-AdminOrElevate {
    [CmdletBinding()]
    param(
        [string]$ScriptPath,
        [hashtable]$Bound = @{},
        [array]$Unbound = @()
    )
    $wp = [Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
    if ($wp.IsInRole([Security.Principal.WindowsBuiltinRole]::Administrator)) { return }

    # V2 兼容：[StringBuilder]::new() 仅 PS 5.0+，用 New-Object 替代
    $sb = New-Object System.Text.StringBuilder
    [void]$sb.Append('-NoProfile -ExecutionPolicy Bypass -File "')
    [void]$sb.Append($ScriptPath)
    [void]$sb.Append('"')
    foreach ($k in $Bound.Keys) {
        $v = $Bound[$k]
        if ($v -is [switch]) {
            if ($v.IsPresent) { [void]$sb.Append(" -$k") }
        } else {
            [void]$sb.Append(" -$k ""$v""")
        }
    }
    foreach ($a in $Unbound) { [void]$sb.Append(" ""$a""") }

    try {
        Start-Process -FilePath 'powershell.exe' 
            -ArgumentList $sb.ToString() 
            -Verb RunAs 
            -WorkingDirectory (Split-Path $ScriptPath)
        exit
    } catch {
        Write-Error ("自动提权失败（可能被取消或受限于组策略）。请右键 PowerShell 选择「以管理员身份运行」后重试。
" + $_)
        exit 1
    }
}

# V2: 添加兼容性辅助函数
function Get-PSVersion {
    <# 安全获取PS版本号，PS 2.0+ 可用 #>
    try { return System.Management.Automation.PSVersionHashTable.PSVersion.Major } catch { return 2 }
}

function Invoke-SafeWmi {
    <# PS版本安全地调用WMI/CIM #>
    param([string], [string] = 'root/cimv2')
    try {
        if (Get-Command Get-CimInstance -ErrorAction SilentlyContinue) {
            Get-CimInstance -ClassName  -Namespace  -ErrorAction Stop
        } else {
            Get-WmiObject -Class  -Namespace  -ErrorAction Stop
        }
    } catch {
        Write-Warning "无法查询  : "
    }
}