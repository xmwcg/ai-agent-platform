<#
.SYNOPSIS  金网通 V2 · 打印机与外设扫描引擎
.DESCRIPTION  PS 2.0+ 兼容。USB/LPT/网络打印机发现 + 驱动信息 + 共享状态 + USB设备列表
#>
param([switch]$Json,[switch]$Quiet)
$r=@{ printers=@(); usbDevices=@(); scanners=@() }

# 打印机列表
try{ if(Get-Command Get-Printer -EA SilentlyContinue){ Get-Printer -EA SilentlyContinue|%{ $r.printers+=@{name=$_.Name; driver=$_.DriverName; port=$_.PortName; shared=$_.Shared; shareName=$_.ShareName; location=$_.Location; status=$_.PrinterStatus; type=$_.Type; default=$_.Default; local=$_.Local} } } }catch{}
if($r.printers.Count -eq 0){
  try{ wmi Win32_Printer|%{ $r.printers+=@{name=$_.Name; driver=$_.DriverName; port=$_.PortName; shared=$_.Shared; shareName=$_.ShareName; location=$_.Location; status=$_.PrinterStatus; default=$_.Default; local=$_.Local; network=$_.Network} } }catch{}
}

# 打印机端口
$r.ports=@()
try{ if(Get-Command Get-PrinterPort -EA SilentlyContinue){ Get-PrinterPort -EA SilentlyContinue|%{ $r.ports+=@{name=$_.Name; address=$_.PrinterHostAddress; protocol=$_.Protocol; description=$_.Description} } } }catch{
  try{ wmi Win32_TCPIPPrinterPort|%{ $r.ports+=@{name=$_.Name; address=$_.HostAddress; protocol='TCP/IP'} } }catch{}
}
if($r.ports.Count -eq 0){ try{ wmi Win32_Printer|Select -Expand PortName -Unique|%{ $r.ports+=@{name=$_} } }catch{} }

# USB 设备
try{ wmi Win32_USBControllerDevice | %{ $dev = [wmi]($_.Dependent); if($dev.Name){ $r.usbDevices+=@{name=$dev.Name; manufacturer=$dev.Manufacturer; deviceID=$dev.DeviceID; status=$dev.Status} } } }catch{}

# 扫描仪/WIA设备
try{ wmi Win32_PnPEntity | ?{ $_.PNPClass -eq 'Image' -or $_.Name -match 'Scanner|WIA' } | %{ $r.scanners+=@{name=$_.Name; pnpClass=$_.PNPClass; status=$_.Status; manufacturer=$_.Manufacturer} } }catch{}

# 打印队列
$r.queues=@()
foreach($p in @($r.printers|?{$_.name})){ try{ $jobs=Get-PrintJob -PrinterName $p.name -EA SilentlyContinue; if($jobs){ $r.queues+=@{printer=$p.name; pending=($jobs|Measure-Object).Count} } }catch{} }

if($Json){$r|ConvertTo-Json -Compress -Depth 4;exit}
if($Quiet){exit}
Write-Host "`n══ 打印机与外设扫描 ══`n" -F Cyan
if($r.printers.Count -eq 0){ Write-Host " 未发现打印机。`n" -F Gray; return }
Write-Host " 打印机: $($r.printers.Count) 台`n" -F White
foreach($p in $r.printers){
  $icon=if($p.default){'⭐'}else{'🖨️'}; $shareIcon=if($p.shared){'✓已共享'}else{'未共享'}
  Write-Host "  $icon $($p.name)" -F $(if($p.default){'Yellow'}else{'White'})
  Write-Host "     驱动: $($p.driver) | 端口: $($p.port) | $shareIcon" -F Gray
}
Write-Host "`n 端口:" -F Yellow
foreach($port in $r.ports){ Write-Host "   $($port.name) $(if($port.address){'→ '+$port.address+' ('+$port.protocol+')'})" -F Gray }
if($r.usbDevices){ Write-Host "`n USB设备: $(($r.usbDevices|Measure-Object).Count) 个" -F White; $r.usbDevices|Select -First 10|%{ Write-Host "   $($_.name)" -F Gray } }
if($r.scanners){ Write-Host "`n 扫描仪/图像设备: $(($r.scanners|Measure-Object).Count) 个" -F White; $r.scanners|%{ Write-Host "   $($_.name)" -F Gray } }
Write-Host ""
function wmi($c){try{if(Get-Command Get-CimInstance -EA SilentlyContinue){Get-CimInstance $c -EA Stop}else{Get-WmiObject $c -EA Stop}}catch{}}