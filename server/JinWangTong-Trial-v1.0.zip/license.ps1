<#
.SYNOPSIS
    金网通 License 离线激活模块（零服务器成本）
.DESCRIPTION
    V2 兼容层：PS 2.0+ 安全。所有 .NET 构造函数替换为 New-Object 调用。
    本地部署产品的授权校验：
      - 生成机器指纹（CPU/主板/系统盘序列号）
      - 由指纹+席位+到期生成离线激活码（license.json，HMAC-SHA256 签名）
      - 启动时校验：签名有效 + 指纹匹配 + 未过期 + 席位未超
#>

$script:LicenseKey = if ($env:LICENSE_KEY) { $env:LICENSE_KEY } else { 'JinWangTong-2026-Local-Key' }
$script:LicensePath = Join-Path $PSScriptRoot 'license.json'

function Get-MachineFingerprint {
    <# 取机器稳定标识，拼接做指纹 #>
    # V2 兼容：Get-CimInstance→Get-WmiObject 降级
    $cpu = $null; $board = $null; $disk = $null
    if (Get-Command Get-CimInstance -ErrorAction SilentlyContinue) {
        $cpu   = (Get-CimInstance Win32_Processor -ErrorAction SilentlyContinue | Select-Object -First 1).ProcessorId
        $board = (Get-CimInstance Win32_BaseBoard -ErrorAction SilentlyContinue | Select-Object -First 1).SerialNumber
        $disk  = (Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='C:'" -ErrorAction SilentlyContinue | Select-Object -First 1).VolumeSerialNumber
    } else {
        $cpu   = (Get-WmiObject Win32_Processor -ErrorAction SilentlyContinue | Select-Object -First 1).ProcessorId
        $board = (Get-WmiObject Win32_BaseBoard -ErrorAction SilentlyContinue | Select-Object -First 1).SerialNumber
        $disk  = (Get-WmiObject Win32_LogicalDisk -Filter "DeviceID='C:'" -ErrorAction SilentlyContinue | Select-Object -First 1).VolumeSerialNumber
    }
    if (-not $cpu) { $cpu = 'CPU-UNKNOWN' }
    if (-not $board) { $board = 'BOARD-UNKNOWN' }
    if (-not $disk) { $disk = 'DISK-UNKNOWN' }
    $raw = "$cpu|$board|$disk"
    # V2 兼容：SHA256::Create() + 字符串处理（.NET 2.0 可用）
    $sha = [System.Security.Cryptography.SHA256]::Create()
    $bytes = $sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($raw))
    $hash = [System.BitConverter]::ToString($bytes).Replace('-', '').Substring(0, 16)
    return $hash
}

function New-LicenseFile {
    param(
        [Parameter(Mandatory = $true)] [string] $Fingerprint,
        [int] $Seats = 10,
        [int] $Days = 365,
        [string] $Edition = 'standard'
    )
    $expire = (Get-Date).AddDays($Days).ToString('yyyy-MM-dd')
    $payload = "$Fingerprint|$Seats|$expire|$Edition"

    # V2 兼容：[HMACSHA256]::new(...) → New-Object（PS 2.0+ 安全）
    $keyBytes = [Text.Encoding]::UTF8.GetBytes($script:LicenseKey)
    $hmacObj = New-Object System.Security.Cryptography.HMACSHA256 -ArgumentList @(,$keyBytes)
    $hmacBytes = $hmacObj.ComputeHash([Text.Encoding]::UTF8.GetBytes($payload))
    $hmacObj.Dispose()
    $hmac = [System.BitConverter]::ToString($hmacBytes).Replace('-', '')

    # V2 兼容：[ordered]@{} 仅 PS 3.0+，PS 2.0 降级为普通 hashtable（JSON序列化后键序可能不同但内容一致）
    try {
        $obj = [ordered]@{
            fingerprint = $Fingerprint
            seats       = $Seats
            expire      = $expire
            edition     = $Edition
            sign        = $hmac
        }
    } catch {
        $obj = @{
            fingerprint = $Fingerprint
            seats       = $Seats
            expire      = $expire
            edition     = $Edition
            sign        = $hmac
        }
    }

    # V2 兼容：-Compress 仅 PS 3.0+，PS 2.0 手动压缩 JSON
    try {
        $json = $obj | ConvertTo-Json -Compress
    } catch {
        $json = ($obj | ConvertTo-Json) -replace "`r`n", '' -replace "`n", '' -replace '\s+', ' '
    }

    # V2 兼容：-Encoding 参数仅 PS 3.0+，PS 2.0 使用 Out-File
    try {
        $encOpt = if ($PSVersionTable.PSVersion.Major -ge 7) { 'utf8BOM' } elseif ($PSVersionTable.PSVersion.Major -ge 5) { 'utf8' } else { 'UTF8' }
        $json | Set-Content -Path $script:LicensePath -Encoding $encOpt
    } catch {
        $json | Out-File -FilePath $script:LicensePath -Encoding UTF8
    }
    Write-Host "已生成 license.json -> $($script:LicensePath) (席位=$Seats 到期=$expire)"
}

function Test-License {
    <# 返回 $true 表示授权有效；否则写原因并返回 $false #>
    if (-not (Test-Path $script:LicensePath)) {
        Write-Warning '未找到 license.json，请先激活。'
        return $false
    }
    try { $lic = Get-Content $script:LicensePath -Raw | ConvertFrom-Json }
    catch { Write-Warning 'license.json 格式损坏。'; return $false }

    $payload = "$($lic.fingerprint)|$($lic.seats)|$($lic.expire)|$($lic.edition)"

    # V2 兼容：同 New-LicenseFile
    $keyBytes = [Text.Encoding]::UTF8.GetBytes($script:LicenseKey)
    $hmacObj = New-Object System.Security.Cryptography.HMACSHA256 -ArgumentList @(,$keyBytes)
    $hmacBytes = $hmacObj.ComputeHash([Text.Encoding]::UTF8.GetBytes($payload))
    $hmacObj.Dispose()
    $expect = [System.BitConverter]::ToString($hmacBytes).Replace('-', '')

    if ($expect -ne $lic.sign) { Write-Warning 'License 签名无效（可能被篡改）。'; return $false }

    $cur = Get-MachineFingerprint
    if ($cur -ne $lic.fingerprint) { Write-Warning '本机指纹与 License 不匹配（换机器需重新激活）。'; return $false }

    if ([datetime]::Parse($lic.expire) -lt (Get-Date)) { Write-Warning "License 已于 $($lic.expire) 过期。"; return $false }

    Write-Host "授权有效：版本=$($lic.edition) 席位=$($lic.seats) 到期=$($lic.expire)"
    return $true
}

# 直接运行本文件时打印指纹，便于发给厂商激活
if ($MyInvocation.InvocationName -ne '.') {
    $fp = Get-MachineFingerprint
    Write-Host "本机指纹(发给厂商激活): $fp"
}